/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;

import java.io.Serializable;

class Barrier extends ColMember {

    private int n;
    private ColGroup group;


    Barrier(String[] args, ColGroupMaster groupMaster) throws CCJException {
	super();

	int numberOfCpus = groupMaster.getNumberOfCpus();
	groupMaster.addMember("myGroup", this);
	group = groupMaster.getGroup("myGroup",numberOfCpus);

	if (args.length != 1) {
	    System.err.println("1 parameter expected: <N> \nNumber of arguments entered = " + args.length);
	    for (int i = 0 ; i < args.length ; i++) {
		System.err.println("Arg " + i + " = "+ args[i]);
	    }
	    System.exit(1);
	}

	try {
	    n = Integer.parseInt(args[0]);
	} catch (NumberFormatException e) {
	    System.err.println("Number format error: " + args[0] + "; " + e);
	    System.exit(1);
	}

	begin();
    }


    public void run() {
	long start, end;
	double time = 0.0;

	try {
	    int rank = group.getRank(this);
	    int nodes = group.size();

	    if (rank == 0) {
		System.out.println("Barrier started, n = " + n);
	    }

	    barrier(group);

	    // warmup
	    for (int i=0;i<n;i++) {
		barrier(group);
	    }

	    System.gc();
	    barrier(group);

	    // real test
	    start = System.currentTimeMillis();

	    for (int i=0;i<n;i++) {
		barrier(group);
	    }

	    end = System.currentTimeMillis();

	    time = end - start;

	    if (rank == 0) {
		System.out.println("Barrier on " + nodes + " cpus took " + (time / 1000.0) + " secs. -> Latency " + ((time * 1000)/ n) + " usec/call");
	    }

	    barrier(group);
	} catch (CCJException e) {
	    System.out.println("Asp.java: Exception: "+ e.toString());
	    e.printStackTrace();
	    System.exit(1);
	}

	System.exit(0);
    }


    public static void main(String[] args) {
	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);
	    new Barrier(args, groupMaster);
	} catch (CCJException e) {
	    System.err.println("Error in PingPong constructor: " + e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

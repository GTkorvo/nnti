/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.Serializable;
import java.util.Random;

class QR_Pivot extends ColMember {
    private static final boolean DEBUG = false;
    private static final int PIVOT_ELT_ELTS = 5;
    private static final double FLT_EPSILON = 1.19209290E-07; // allow EPS fault

    private static final boolean verify = false;

    private static boolean monitor_load_balance = false;
    private static int max_unbalance = -1;
    private static final double UNBALANCE_FAC = 0.02; /* Allow load imbalace 1.02 */
    private static double pivot_tolerance = 1.2;

    private static long reduce_timer;
    private static long allreduce_timer;

    private static double Eps;
    private MaxIntReduce maxIntReduceObject = new MaxIntReduce();
    private Random random = null;
    private int seed_offset = 0;

    private ColGroup group;
    private int N;

    private static void ASSERT(boolean b) {
		if (!DEBUG)
			return;
        if (!b) {
	    Exception e = new RuntimeException("Assertion failed");
            e.printStackTrace();
            System.exit(11);
        }
    }


    void setGroup(ColGroup group) {
        this.group = group;
    }


    QR_Pivot(int N) throws CCJException {
        super();
        this.N = N;
    }


    private static int min(int m, int n) {
        return m < n ? m : n;
    }

    
    private static double eucl_norm2(int col, int from, double A[], int m) {
        double sum;
        int mycol;
        int i;

        sum = 0.0;
        mycol = col * m;
        from += mycol;
        m += mycol;
        for (i = from; i < m; i++) {
            sum += A[i] * A[i];
        }

        return sum;
    }


    private static void householder_vector(int col, int iter, double A[],
            int m, double v[], double norm) {
        int mycol;
        int i;

        if (norm == 0.0) {
            return;
        }

        mycol = col * m;
        norm = 1.0 / norm;
        for (i = iter; i < m; i++) {
            v[i] = A[i + mycol] * norm;
        }
        v[iter] += 1.0;
    }



    private static void factor_my_columns(int me, int ncpus, int pivot,
            int first_col, int my_cols, double A[], int local_perm[],
            int m, int iter, double v[]) {

        double tau;
        int mycol;
        int i;
        int j;

        double old_norm = 0.0;
        double new_norm;


        if (pivot == me) {
            first_col++;
        }

        for (j = first_col; j < my_cols; j++) {
            if (DEBUG) {
                if (local_perm == null) {
                    old_norm = eucl_norm2(j, iter, A, m);
                } else {
                    old_norm = eucl_norm2(local_perm[j], iter, A, m);
                }
            }
            tau = 0.0;
            if (local_perm == null) {
                mycol = j * m;
            } else {
                mycol = local_perm[j] * m;
            }
            for (i = iter; i < m; i++) {
                tau += v[i] * A[i + mycol];
            }
            tau /= v[iter];
            for (i = iter; i < m; i++) {
                A[i + mycol] -= tau * v[i];
            }
            if (DEBUG) {
                if (local_perm == null) {
                    new_norm = eucl_norm2(j, iter, A, m);
                } else {
                    new_norm = eucl_norm2(local_perm[j], iter, A, m);
                }
                ASSERT(Math.abs(old_norm / new_norm - 1.0) < Eps);
            }
        }
    }

    
    private void random_fill(int me, int ncpus, double A[], int m, int n,
            double bound) {
        int i;
        int j;
        int mycol;
        int max_my_cols;
        double scale;
        double offset;


        if (bound == 0.0) {
            scale = 1.0;
            offset = 0.0;
        } else {
            scale = bound / (1.0 * Integer.MAX_VALUE);
            if (bound > 0.0) { /* Scale around zero */
                offset = - bound / 2.0;
            } else { /* Scale above zero */
                offset = 0;
            }
        }
        max_my_cols = (n + ncpus - me - 1) / ncpus;
        for (j = 0; j < max_my_cols; j++) {
            mycol = j * m;
            random = new Random(j * ncpus + me + seed_offset); /* Want the same value in // */
            for (i = 0; i < m; i++) {
                ASSERT(i + mycol < ((n + ncpus - 1) / ncpus) * m);
                A[i + mycol] = Math.abs(random.nextInt()) * scale + offset;
                ASSERT(bound <= 0.0 ||
                        Math.abs(A[i + mycol]) <= bound / 2.0);
                ASSERT(bound >= 0.0 ||
                        (A[i + mycol] <= bound && A[i + mycol] >= 0));
            }
        }
    }


    private void qrfac(int me, int ncpus, double A[], double rdiag[],
            QR_PIVOT_IX_T perm[], int m, int n) throws CCJException {
        int iter;
        int n_iter;
        int i;
        int mycol = 0;
        int my_cols;
        double v[];
        int err;
        int col = 0; /* Initialize to defy gcc warning */
        double subcol_norm2[] = null;
        double safe_subcol_norm2[] = null;
        Pivot_elt_t local_pivot;
        Pivot_elt_t pivot;
        int local_perm[] = null;
        int max_cols_left = 0;
        int max_cols_sum = 0 ;
        int my_cols_left;
        int first_col;
        int pivot_owner;
        double ajnorm = 0.0;
        int swap;
        int unbalance;


        local_pivot = new Pivot_elt_t();
        pivot = new Pivot_elt_t();
        if (max_unbalance >= 0) {
            unbalance = (int) max_unbalance;
        } else {
            unbalance = (int)((n + (ncpus / UNBALANCE_FAC) - 1) /
                    (ncpus / UNBALANCE_FAC));
        }

        n_iter = min(m, n);
        v = new double[m + 1];
        my_cols = (n + ncpus - me - 1) / ncpus;
        subcol_norm2 = new double[my_cols];

        if (perm != null) { /* Init stuff needed for pivoting */
            safe_subcol_norm2 = new double[my_cols];
            local_perm = new int[my_cols];

            for (i = 0; i < my_cols; i++) {
                subcol_norm2[i] = eucl_norm2(i, 0, A, m);
                safe_subcol_norm2[i] = subcol_norm2[i];
                local_perm[i] = i;
            }
        }

        col = 0;
        first_col = 0;
        max_cols_sum = 0;
        for (iter = 0; iter < n_iter; iter++) {

            if (perm != null) { /* Do pivoting */

                if (iter > 0) {
                    /* Update norms to 1 shorter columns */
                    for (i = first_col; i < my_cols; i++) {
						{

                            int mytmpcol;
                            double diag_iter2;
                            double old_norm = subcol_norm2[local_perm[i]];
                            double calc_norm;

                            calc_norm = eucl_norm2(local_perm[i],
                                    iter - 1, A, m);
                            ASSERT(Math.abs( subcol_norm2[local_perm[i]] /
                                    calc_norm - 1.0) < 4 * Eps);

                            mytmpcol = local_perm[i] * m;
                            diag_iter2 = A[iter - 1 + mytmpcol];
                            diag_iter2 *= diag_iter2;
                            ASSERT(diag_iter2 /
                                    subcol_norm2[local_perm[i]] -
                                    1.0 < 2 * Eps);
                            subcol_norm2[local_perm[i]] -= diag_iter2;
                            if (subcol_norm2[local_perm[i]] <
                                    400 * FLT_EPSILON *
                                    safe_subcol_norm2[local_perm[i]]) {
                        
                                subcol_norm2[local_perm[i]] =
                                        eucl_norm2(local_perm[i],
                                        iter, A, m);
                                safe_subcol_norm2[local_perm[i]] =
                                        subcol_norm2[local_perm[i]];
                            }
                            ASSERT(subcol_norm2[local_perm[i]] <= old_norm);
                            ASSERT(subcol_norm2[local_perm[i]] <
                                    old_norm || diag_iter2 < FLT_EPSILON);
                            calc_norm =
                                    eucl_norm2(local_perm[i], iter, A, m);
                            ASSERT(Math.abs( subcol_norm2[local_perm[i]] /
                                    calc_norm - 1.0) < 2 * Eps);

                        }

                    }
                }


                /* First find local maximum norm */
                /* 0 entry works even if n % ncpus != 0 */
                local_pivot.index = -1;
                local_pivot.norm = 0.0;
                for (i = first_col; i < my_cols; i++) {
                    if (subcol_norm2[local_perm[i]] > local_pivot.norm) {
                        local_pivot.norm = subcol_norm2[local_perm[i]];
                        local_pivot.index = i;
                    }
                }
                /* Translate to global column number */
                local_pivot.index = me + local_pivot.index * ncpus;
                local_pivot.cols = first_col;
                local_pivot.max_cols = iter / ncpus + 1 + unbalance;
		if (local_pivot.cols < local_pivot.max_cols) {
		    local_pivot.max_over_max_cols = local_pivot.norm;
		} else {
		    local_pivot.max_over_max_cols = 0.0;
		}

                /* Find global max norm from local max norms */
                allreduce_timer = System.currentTimeMillis();
                reduce_timer = System.currentTimeMillis();

                Serializable object = null;
                object = allReduce(group, local_pivot, local_pivot);
                pivot = (Pivot_elt_t) object;
                if (DEBUG)
                    System.out.println("Result of allReduce(g,"+
                            local_pivot + ",,0) ="+object);

                allreduce_timer =
                        System.currentTimeMillis() - allreduce_timer;

                if (pivot_tolerance * pivot.max_over_max_cols <
                        pivot.norm) {
                    if (me == 0) {
                        System.err.println("Need load balancing phase iter "+
                                iter + " norm "+ pivot.norm + " max(cols)norm "+
                                pivot.max_over_max_cols);
                    }
                }
                pivot_owner = pivot.index % ncpus;
                perm[iter].owner = pivot_owner;
            }
            else {
                pivot.index = iter;
                pivot_owner = pivot.index % ncpus;
                if (pivot_owner == me) {
                    col = pivot.index / ncpus;
                    subcol_norm2[col] = eucl_norm2(first_col, iter, A, m);
                }
            }

            if (pivot_owner == me) { /* I own the pivot column */
                /* Calculate the Householder vector */
                reduce_timer = System.currentTimeMillis() - reduce_timer;
                col = pivot.index / ncpus;
                if (perm != null) {
                    swap = local_perm[col];
                    local_perm[col] = local_perm[first_col];
                    local_perm[first_col] = swap;
                    col = swap;
                    perm[iter].col = col;
                    ASSERT(local_perm[col] < my_cols);
                    ASSERT(local_perm[first_col] < my_cols);
                }
                mycol = col * m;
                if (DEBUG)
                    System.out.println(me + ": subcol_norm2["+col + "] "+
                            subcol_norm2[col] + "eucl_norm2("+ +col +
                            ") "+ eucl_norm2(col, iter, A, m));
                if (A[iter + mycol] < 0.0) {
                    ajnorm = -Math.sqrt(subcol_norm2[col]);
                } else {
                    ajnorm = Math.sqrt(subcol_norm2[col]);
                }
                if (ajnorm == 0.0) {
                    System.err.println("Singular matrix : column "+
                            iter + "norm = 0");
                }
                householder_vector(col, iter, A, m, v, ajnorm);
                ASSERT(col < my_cols);
                ASSERT(first_col < my_cols);
            }
            /* Broadcast the Householder vector */

            // Should be broadcast of v[iter] till v[m-1], but this can't be done in CCJ. 
            // So an additional copy is needed twice
            double tmp[] = null;
            if (me == pivot_owner) {
                tmp = new double[m - iter];
                for (int j = iter ; j < m ; j++)
                    tmp[j - iter] = v[j];
            }
// System.out.println(me + ": > bcast[" + pivot_owner + "] " + iter); System.out.flush();
            tmp = (double[]) broadcast(group, tmp, pivot_owner);
// System.out.println(me + ": < bcast[" + pivot_owner + "] " + iter); System.out.flush();
            if (me != pivot_owner)
                for (int j = iter; j < m ; j++)
                    v[j] = tmp[j - iter];

            /* Use v to factor my columns */
            factor_my_columns(me, ncpus, pivot_owner, first_col,
                    my_cols, A, local_perm, m, iter, v);

            if (pivot_owner == me) {
                /* Record v in subdiag column */
                for (i = iter; i < m; i++) {
                    ASSERT(i + mycol < ((n + ncpus - 1) / ncpus) * m);
                    A[i + mycol] = v[i];
                }
                rdiag[col] = -ajnorm;
                first_col++;
            }

            if (monitor_load_balance) {
                my_cols_left = my_cols - first_col;

                Integer integer;
                integer = (Integer) reduce(group,
                        new Integer(my_cols_left), maxIntReduceObject, 0);

                if (me == 0) {
                    max_cols_sum += integer.intValue();
                    // System.out.println("max cols "+ max_cols_left + " av. col "+ ((n - iter) / (1.0 * ncpus)));
                }
            }
        }

        if (monitor_load_balance && me == 0) {
            System.out.println("Load imbalance: <max cols>"+
                    (max_cols_sum / (1.0 * n_iter)) + "  <cols> "+
                    (n * (n - 1) / (2.0 * n_iter * ncpus)) + " factor "+
                    ((max_cols_sum / (1.0 * n_iter)) /
                    (n * (n - 1) / (2.0 * n_iter * ncpus))));
        }
    }


    private static void verify_equality(int me, int ncpus, double A[],
            double B[], int perm[], int m, int n) {
        int i;
        int j;
        int my_cols;
        double err;

        my_cols = (n + ncpus - me - 1) / ncpus;
        for (i = 0; i < m; i++) {
            for (j = 0; j < my_cols; j++) {
                if (A[i + j * m] == 0.0) {
                    err = Math.abs(B[i + j * m]);
                } else {
                    err = Math.abs(A[i + j * m] / B[i + j * m] - 1.0);
                }
                if (err > Eps) {
                    System.err.println("Verify error A["+i + ","+me +
                            j * ncpus + "]\t= "+A[i + j * m] + " A'["+
                            i + ","+me + j * ncpus + "]\t= "+B[i + j * m]);
                }
            }

        }
    }


    private void qr_verify(int me, int ncpus, double A_orig[], double A[],
            double rdiag[], QR_PIVOT_IX_T perm[], int m,
            int n) throws CCJException {
        int iter;
        int n_iter;
        int first_col;
        int col = 0;
        int mycol;
        int my_cols;
        double v[];
        int owner;
        int i;
        int err;
        int local_perm[] = null;

        v = new double[m];

        n_iter = min(n, m);
        my_cols = (n + ncpus - me - 1) / ncpus;

        if (perm != null) { /* Init stuff to undo the pivot permutation */
            local_perm = new int[my_cols];

            col = 0;
            for (i = 0; i < n_iter; i++) {
                if (perm[i].owner == me) {
                    local_perm[col++] = perm[i].col;
                }
            }
            ASSERT(col == my_cols);
        }

        first_col = my_cols;
        for (iter = n_iter - 1; iter >= 0; iter--) {
            if (perm == null) {
                owner = iter % ncpus;
                if (owner == me) {
                    first_col--;
                    col = first_col;
                }
            } else {
                owner = perm[iter].owner;
                if (owner == me) {
                    first_col--;
                    col = local_perm[first_col];
                    ASSERT(col == perm[iter].col);
                }
            }
            if (owner == me) {
                mycol = col * m;
                for (i = iter; i < m; i++) {
                    v[i] = A[i + mycol];
                }
                A[iter + mycol] = rdiag[col];
                for (i = iter + 1; i < m; i++) {
                    A[i + mycol] = 0.0;
                }
            }
            // Do a broadcast of a number of elements
            double tmp[] = null;
            if (me == owner) {
                tmp = new double[m - iter];
                for (int j = iter ; j < m ; j++)
                    tmp[j - iter] = v[j];
           }
System.out.println(me + ": > bcast/2 " + iter); System.out.flush();
            tmp = (double[]) broadcast(group, tmp, owner);
System.out.println(me + ": < bcast/2 " + iter); System.out.flush();
            ASSERT(tmp != null);
            ASSERT(tmp.length == m - iter);

            if (me != owner)
                for (int j = iter; j < m ; j++)
                    v[j] = tmp[j - iter];

            factor_my_columns(me, ncpus, -1, first_col, my_cols, A,
                    local_perm, m, iter, v);
        }

        verify_equality(me, ncpus, A_orig, A, null, m, n);
    }

    
    private void qr_init() {

        Eps = FLT_EPSILON;

    }


    private void qr_end() {
    }


    public void run() {
        int me;
        int ncpus;
        int i;
        int my_cols;
        int m = 169;
        int n;
        int col_surplus = 0;
        double A[];
        double A_orig[] = null;
        double rdiag[];
        int option;
        int err;
        long t;
        double bound = 2000.0;
        int flat_size;
        boolean pos_bound = false;
        QR_PIVOT_IX_T perm[] = null;
        int pivot = 1;

        try {
            me = group.getRank(this);
            ncpus = group.size();
            m = N;
            qr_init();

            n = m + col_surplus;

            if (bound != 0.0 && pos_bound) {
                bound = -bound;
            }

            if (me == 0) {
                System.out.println("QR of "+m + " x "+ n);
            }

            random = new Random(me);

            my_cols = (n + ncpus - me - 1) / ncpus;
            flat_size = my_cols * m;
            rdiag = new double[my_cols];
            A = new double[flat_size];
            random_fill(me, ncpus, A, m, n, bound);

            if (verify) {
                A_orig = new double[flat_size];
                System.arraycopy(A, 0, A_orig, 0, flat_size);
            }

            if (pivot != 0) {
                perm = new QR_PIVOT_IX_T[min(m, n)];
                for (int j = 0 ; j < min(m, n); j++)
                    perm[j] = new QR_PIVOT_IX_T();
            }

            t = System.currentTimeMillis();
            qrfac(me, ncpus, A, rdiag, perm, m, n);
            t = System.currentTimeMillis() - t;

            if (me == 0) {
                System.out.println("QR done t = " + t);
            }

            if (verify) {
                t = System.currentTimeMillis();

                qr_verify(me, ncpus, A_orig, A, rdiag, perm, m, n);
                t = System.currentTimeMillis() - t;

                if (me == 0) {
                    System.out.println("QR verified t= "+ t);
                }
            }
            qr_end();
            System.exit(0);
        } catch (CCJException e) {
            System.err.println("Exception: "+ e.toString());
            e.printStackTrace();
            System.exit(1);
        }
    }

}

/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.Serializable;

class SumDoubleReduce implements Reducible {

    public Serializable reduce (Serializable obj1, Serializable obj2) {
        if (obj2 == null)
            return obj1;
        Double d1 = (Double) obj1;
        Double d2 = (Double) obj2;

        return new Double(d1.doubleValue() + d2.doubleValue());
    }

}

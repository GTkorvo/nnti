/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.*;
import java.util.Random;


class QR extends ColMember {
	private static final boolean DEBUG=false;
    private static final double FLT_EPSILON = 1.19209290E-07;
    private ColGroup group;
    private static boolean monitor_load_balance = true;
    private static double Eps;
    private int N;
    private int seed_offset = 0;
    private Random random = null;

    private MaxIntReduce maxIntReduceObject = new MaxIntReduce();

    public void setGroup(ColGroup group) {
        this.group = group;
    }


    private static double eucl_norm(int index, int from, double A[], int m) {
        double sum;
        int mycol;
        int i;

        sum = 0.0;
        mycol = index * m;
        from += mycol;
        m += mycol;
        for (i = from; i < m; i++) {
            sum += A[i] * A[i];
        }

        return Math.sqrt(sum);
    }


    /*
      * Compute Householder rotation vector
    */
    static void householder_vector(int col, int iter, double A[],
            int m, double v[], double norm) {
        int mycol;
        int i;

        if (norm == 0.0) {
            return;
        }
        mycol = col * m;
        norm = 1.0 / norm;
        for (i = iter; i < m; i++) {
            v[i] = A[i + mycol] * norm;
        }
        v[iter] += 1.0;
    }


    private static void factor_my_columns(int me, int ncpus, int pivot,
            int my_cols, double A[], int m, int iter, double v[]) {
        double tau;
        int mycol;
        int i;
        int j;
        int first_col;

        first_col = iter / ncpus;

        for (j = first_col; j < my_cols; j++) {
            tau = 0.0;
            mycol = j * m;
            for (i = iter; i < m; i++) {
                tau += v[i] * A[i + mycol];
            }
            tau /= v[iter];
            if (j == first_col && pivot == me) {
                A[iter + mycol] -= tau * v[iter];
            } else {
                for (i = iter; i < m; i++) {
                    A[i + mycol] -= tau * v[i];
                }
            }
        }
    }


    private void qrfac(int me, int ncpus, double A[], double rdiag[],
            QR_PIVOT_IX_T perm[], int m, int n) throws Exception {
        int iter;
        int n_iter;
        int i;
        int mycol = 0; // Init to defy java error.
        int my_cols;
        double v[];
        int pivot;
        int err;
        int col = 0; 		 // Init to defy java error.
        double ajnorm = 0.0; // Init to defy java error.

        int max_cols_sum;
        int max_cols_left;
        int my_cols_left;

        n_iter = min(m, n);
        v = new double[n + 1];
        my_cols = (n + ncpus - me - 1) / ncpus;

        max_cols_sum = 0;
        col = 0;
        for (iter = 0; iter < n_iter; iter++) {

            pivot = iter % ncpus;
            if (pivot == me) { /* I own the pivot column */
                /* Calculate the Householder vector */
                ajnorm = eucl_norm(col, iter, A, m);
                if (ajnorm == 0.0) {
                    System.err.println("Singular matrix : column "+
                            iter + " = 0");
                }
                mycol = col * m;
                if (A[iter + mycol] < 0.0) {
                    ajnorm = -ajnorm;
                }
                householder_vector(col, iter, A, m, v, ajnorm);
            }

            /* Broadcast Householder vector v */
            // Should be broadcast of v[iter] till v[m-1], but this can't be done in CCJ. 
            // So an additional copy is needed twice

            double tmp[] = null;
            if (me == pivot) {
                tmp = new double[m - iter];
                for (int j = iter ; j < m ; j++)
                    tmp[j - iter] = v[j];
            }
            tmp = (double[]) broadcast(group, tmp, pivot);
            if (me != pivot)
                for (int j = iter; j < m ; j++)
                    v[j] = tmp[j - iter];

            /* Factor my columns using v */
            factor_my_columns(me, ncpus, pivot, my_cols, A, m, iter, v);

            if (pivot == me) {
                /* Record v in subdiag column */
                for (i = iter; i < m; i++) {
                    ASSERT(i + mycol < ((n + ncpus - 1) / ncpus) * m);
                    A[i + mycol] = v[i];
                }
                /* Record A[j,j] in rdiag[j] */
                rdiag[col] = -ajnorm;
                col++;
            }

            if (monitor_load_balance) {
                my_cols_left = my_cols - col;
                Integer integer;
                integer = (Integer) reduce(group,
                        new Integer(my_cols_left), maxIntReduceObject, 0);

                if (me == 0) {
                    max_cols_left = integer.intValue();
                    max_cols_sum += max_cols_left;
                    // System.out.println("max cols "+ max_cols_left + " av. cols "+ ((n - iter) / (1.0 * ncpus)));
                }
            }
        }

        if (monitor_load_balance && me == 0) {
            System.out.println("Load imbalance: <max cols> " +
                    (max_cols_sum / (1.0 * n_iter)) + " <cols> " +
                    (n * (n - 1) / (2.0 * n_iter * ncpus)) + " factor "+
                    ((max_cols_sum / (1.0 * n_iter)) /
                    (n * (n - 1) / (2.0 * n_iter * ncpus))));
        }
    }


    private void verify_equality(int me, int ncpus, double A[], double B[],
            int m, int n) {

        int i;
        int j;
        int my_cols;
        double err;

        my_cols = (n + ncpus - me - 1) / ncpus;
        for (i = 0; i < m; i++) {
            for (j = 0; j < my_cols; j++) {
                if (A[i + j * m] == 0.0) {
                    err = Math.abs(B[i + j * m]);
                } else {
                    err = Math.abs(A[i + j * m] / B[i + j * m] - 1.0);
                }
                if (err > Eps) {
                    System.err.println("Verify error A["+i + ","+j + "]\t= "+
                            A[i + j * m] + " delta = "+
                            (A[i + j * m] / B[i + j * m] - 1.0));
                }
            }
        }
    }


    private void qr_verify(int me, int ncpus, double A_orig[], double A[],
            double rdiag[], QR_PIVOT_IX_T perm[], int m,
            int n) throws Exception {
        int iter;
        int n_iter;
        int col;
        int mycol;
        int my_cols;
        double v[];
        int owner;
        int i;
        int err;

        barrier(group);
        v = new double[n];

        n_iter = min(n, m);
        my_cols = (n + ncpus - me - 1) / ncpus;

        col = my_cols;
        for (iter = n_iter - 1; iter >= 0; iter--) {
            owner = iter % ncpus;
            if (owner == me) {
                col--;
                mycol = col * m;
                for (i = iter; i < m; i++) {
                    v[i] = A[i + mycol];
                }
                A[iter + mycol] = rdiag[col];
                for (i = iter + 1; i < m; i++) {
                    A[i + mycol] = 0.0;
                }
            }

            // Should be a simple broadcast but needs two additional copies
            double tmp[] = null;
            if (me == owner) {
                tmp = new double[m - iter];
                for (int j = iter ; j < m ; j++)
                    tmp[j - iter] = v[j];
            }
            tmp = (double[]) broadcast(group, tmp, owner);
            if (me != owner)
                for (int j = iter; j < m ; j++)
                    v[j] = tmp[j - iter];

            factor_my_columns(me, ncpus, -1, my_cols, A, m, iter, v);
        }

        verify_equality(me, ncpus, A_orig, A, m, n);
    }


    private void qr_init() {
        Eps = FLT_EPSILON;
    }


    private void qr_end() {
    }


    QR(int N) throws Exception {
        super();
        this.N = N;
    }


    private void ASSERT(boolean b) {
    	if (!DEBUG)
    		return;
        if (!b) {
            System.err.println("Assertion failed");
            Exception e = new RuntimeException("Assertion failed");
            e.printStackTrace();
            System.exit(9);
        }
    }


    private void random_fill(int me, int ncpus, double A[], int m, int n,
            double bound) {
        int i;
        int j;
        int mycol;
        int max_my_cols;
        double scale;
        double offset;

        if (bound == 0.0) {
            scale = 1.0;
            offset = 0.0;
        } else {
            scale = bound / (1.0 * Integer.MAX_VALUE);
            if (bound > 0.0) { /* Scale around zero */
                offset = - bound / 2.0;
            } else { /* Scale above zero */
                offset = 0;
            }
        }
        max_my_cols = (n + ncpus - me - 1) / ncpus;
        for (j = 0; j < max_my_cols; j++) {
            mycol = j * m;
            random = new Random(j * ncpus + me + seed_offset); /* Want the same value in // */
            for (i = 0; i < m; i++) {
                ASSERT(i + mycol < ((n + ncpus - 1) / ncpus) * m);
                A[i + mycol] = Math.abs(random.nextInt()) * scale + offset;
                ASSERT(bound <= 0.0 ||
                        Math.abs(A[i + mycol]) <= bound / 2.0);
                ASSERT(bound >= 0.0 ||
                        (A[i + mycol] <= bound && A[i + mycol] >= 0));
            }
        }
    }


    private static int min(int m, int n) {
        return m < n ? m : n;
    }


    public void run() {
        int me;
        int ncpus;
        int i;
        int my_cols;
        int m = 169;
        int n;
        int col_surplus = 0;
        double A[];
        double A_orig[] = null;
        double rdiag[];
        int option;
        int err;
        long t;
        double bound = 2000.0;
        int flat_size;
        boolean verify = true;
        boolean pos_bound = false;
        QR_PIVOT_IX_T perm[] = null;
        int pivot = 1;

        try {
            me = group.getRank(this);
            ncpus = group.size();
            m = N;
            qr_init();

            n = m + col_surplus;

            if (bound != 0.0 && pos_bound) {
                bound = -bound;
            }

            if (me == 0) {
                System.out.println("QR of "+m + " x "+ n);
            }

            random = new Random(me);

            my_cols = (n + ncpus - me - 1) / ncpus;
            flat_size = my_cols * m;
            rdiag = new double[my_cols];
            A = new double[flat_size];
            random_fill(me, ncpus, A, m, n, bound);

            if (verify) {
                A_orig = new double[flat_size];
                System.arraycopy(A, 0, A_orig, 0, flat_size);
            }

            if (pivot != 0) {
                perm = new QR_PIVOT_IX_T[min(m, n)];
            }

            t = System.currentTimeMillis();
            qrfac(me, ncpus, A, rdiag, perm, m, n);
            t = System.currentTimeMillis() - t;

            if (me == 0) {
                System.out.println("QR done t = " + t);
            }

            if (verify) {
                t = System.currentTimeMillis();

                qr_verify(me, ncpus, A_orig, A, rdiag, perm, m, n);
                t = System.currentTimeMillis() - t;

                if (me == 0) {
                    System.out.println("QR verified t= "+ t);
                }
            }
            qr_end();
            System.exit(0);
        } catch (CCJException e) {
            System.err.println("Exception: "+ e.toString());
            e.printStackTrace();
            System.exit(1);
        }
    }

}

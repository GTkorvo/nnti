/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.Serializable;

class Pivot_elt_t implements Serializable, Reducible {
    private static final boolean DEBUG = false;
    private static final int PIVOT_ELT_ELTS = 5;
    private static final double FLT_EPSILON = 1.19209290E-07;

    protected double norm;
    protected double max_over_max_cols;
    protected int index;
    protected int cols;
    protected int max_cols;
    private static boolean monitor_load_balance = true;
    private static int max_unbalance = -1;
    private static final double UNBALANCE_FAC = 0.02; /* Allow load imbalace 1.02 */
    private static double pivot_tolerance = 1.2;

    private static double Eps;

    private static void ASSERT(boolean b) {
    	if (!DEBUG)
    		return;
        if (!b) {
            Exception e = new RuntimeException("Assertion failed");
            e.printStackTrace();
            System.exit(11);
        }
    }


    public Serializable reduce(Serializable a0, Serializable a1) {
        Pivot_elt_t p0 = (Pivot_elt_t) a0;
        Pivot_elt_t p1 = (Pivot_elt_t) a1;
        ASSERT(p0.max_cols >= 0);
        ASSERT(p1.max_cols >= 0);
        ASSERT(p0.max_cols == p1.max_cols);
        if (DEBUG) {
            System.out.println("reduce_pivot: pivot0 = " + p0 +
				" pivot1 = " + p1);
	}
        if (p0.cols < p0.max_cols) {
            if (p1.cols < p1.max_cols) {
		/* p0, p1 both candidates for balanced selection */
                if (p0.max_over_max_cols > p1.max_over_max_cols) {
                    p1.max_over_max_cols = p0.max_over_max_cols;
		    p1.cols = p0.cols;
		    p1.index = p0.index;
                } else {
		    /* no-op selects p1 */
		}
            } else {
		/* p0 is, p1 isn't a candidate for balanced selection */
                p1.max_over_max_cols = p0.max_over_max_cols;
                p1.cols = p0.cols;
		p1.index = p0.index;
            }
        } else {
	    if (p1.cols >= p1.max_cols) {
		/* p0, p1 aren't candidates for balanced selection */
		p1.max_over_max_cols = 0.0;
	    } else {
		/* p1 is, p0 isn't a candidate for balanced selection */
		/* no-op selects p1 */
	    }
        }

        if (p0.norm > p1.norm) {
	    /* Don't select irrespective of load imbalance, but monitor
	     * max(norm) */
            p1.norm = p0.norm;
        }

        if (DEBUG) {
            System.out.println("reduce_pivot: result = " + p1);
	}

        return p1;
    }


    public String toString() {
	return "[norm " + norm + ", max_over_max_cols " + max_over_max_cols +
		", index " + index + ", cols " + cols +
		", max_cols " + max_cols + "]";
    }

}

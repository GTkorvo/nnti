/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.rmi.RemoteException;

class MyMainQR {
    int nobjects;
    int N;

    void start(String args[]) {
        ColGroup group = null;
        int numberOfCpus;

        // System.out.println("Starting groupmaster.");
        ColGroupMaster groupMaster = new ColGroupMaster(args);
        // System.out.println("Groupmaster created.");
        numberOfCpus = groupMaster.getNumberOfCpus();

        if (args.length != 2) {
            System.err.println("2 parameters expected: "+
            			"<number of objects per cpu> <N>\nNumber of arguments entered = "+
                    args.length);
            for (int i = 0 ; i < args.length ; i++) {
                System.err.println("Arg " + i + " = "+ args[i]);
            }

            System.exit(1);
        }

        try {
            nobjects = Integer.parseInt(args[0]);
	} catch (NumberFormatException e) {
	    System.err.println("Number format error: " + args[0] + "; " + e);
            System.exit(1);
        }
        try {
            N = Integer.parseInt(args[1]);
	} catch (NumberFormatException e) {
	    System.err.println("Number format error: " + args[1] + "; " + e);
            System.exit(1);
        }

        // System.out.println("CCJ running test on "+ numberOfCpus + " CPUS, " + nobjects + " members per CPU, N= "+ N);

        QR myMembers[] = new QR[nobjects];

        try {
            for (int i = 0 ; i < nobjects; i++) {
                myMembers[i] = new QR(N);
                groupMaster.addMember("myGroup", myMembers[i]);
            }

        } catch (CCJException e) {
            System.err.println("Something went wrong during creation of groups "+e);
            e.printStackTrace();
            System.exit(1);
        }

        try {
            for (int i = 0 ; i < nobjects ; i++) {
                group = groupMaster.getGroup("myGroup",
                        numberOfCpus * nobjects);
                // System.out.println("MyMain: Got a group back");
                myMembers[i].setGroup(group);
                myMembers[i].begin();
            }
        } catch (CCJException e) {
            System.err.println("Cannot start member: "+e);
            e.printStackTrace();
            System.exit(2);
        }
    }


    public static void main (String args[]) {
        new MyMainQR().start(args);
    }

}

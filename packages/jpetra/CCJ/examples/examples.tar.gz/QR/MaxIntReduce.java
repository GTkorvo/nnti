/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.Serializable;

class MaxIntReduce implements Reducible {
    public Serializable reduce (Serializable obj1, Serializable obj2) {
        if (obj2 == null)
            return obj1;
        Integer i1 = (Integer) obj1;
        Integer i2 = (Integer) obj2;
        if (i1.intValue() >= i2.intValue())
            return i1;
        else
            return i2;
    }

}


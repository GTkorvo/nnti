/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import java.io.*;

import CCJ.*;

class Test extends ColMember {

    private static final int DEFAULT_N = 1000;

    private int arraysize;
    private int count;
    ColGroup group;
    ColGroupMaster groupMaster;


    Test(String[] args, ColGroupMaster groupMaster) throws CCJException {
	super();
	this.groupMaster = groupMaster;

	if (args.length != 2) {
	    System.err.println("2 parameters expected: arraysize runs\nNumber of arguments entered = "+
		       args.length);
	    for (int i = 0 ; i < args.length ; i++) {
		System.err.println("Arg " + i + " = "+ args[i]);
	    }
	    System.exit(1);
	}

	arraysize = Integer.parseInt(args[0]);
	count = Integer.parseInt(args[1]);

	int numberOfCpus = groupMaster.getNumberOfCpus();

	groupMaster.addMember("myGroup", this);
	group = groupMaster.getGroup("myGroup", numberOfCpus);

	begin();
    }


    public void run() {

	int cpu = -1;

	try {
	    ByteArray result;
	    byte [] data;

	    cpu = group.getRank(this);
	    int nodes = group.size();

	    int d = (arraysize + nodes - 1) / nodes;
	    int m = arraysize % nodes;

	    int offset = cpu * d;
	    int size = d;

	    if (cpu >= (nodes - m)) {
		size += 1;
		offset += cpu - (nodes - m);
	    }

	    if (cpu == 0) {
		System.out.println("Started Test");
	    }

	    data = new byte[size];
	    result = new ByteArray(arraysize);

	    for (int i = 0; i < size; i++) {
		data[i] = (byte)(offset + i);
	    }

	    // Wait for the others.
	    barrier(group);
System.err.println(cpu + ": I'm up...");
	    long start = System.currentTimeMillis();

	    for (int i=0;i<count;i++) {
		allGather(group, result, data);
	    }

	    // Wait for the others.
	    barrier(group);

	    long end = System.currentTimeMillis();

	    int x = 0;
	    for (int i = 0; i < nodes; i++) {
		byte[] a = (byte[])result.elementAt(i, nodes);
		for (int j = 0; j < a.length; j++) {
		    if (a[j] != (byte)x) {
			System.err.println("Uh oh -- result[" + x + "] = " + a[j] + ", should be " + (byte)x);
		    }
		    x++;
		}
	    }

	    if (cpu == 0) {

		long time   = end - start;
		double usec = 1000.0*time;
		double sec  = time/1000.0;
		double mbytes  = (arraysize*count)/(1024.0*1024.0);

		System.out.println("----------------------------" +
			   "\nallGather : " +
			   "\n#seconds  : " + sec +
			   "\n#arraysize: " + arraysize +
			   "\n#count    : " + count +
			   "\nallgather : " + (usec/count) + " usec/allgather" +
			   "\n          : " + (mbytes/ sec) + " MBytes/sec." +
			   "\n----------------------------\n");
	    }

	    // Wait for the others.
	    barrier(group);
	    System.exit(0);

	} catch (CCJException e) {
	    System.out.println(cpu + ": Test : oops, something is wrong !");
	    e.printStackTrace();
	}
    }


    public static void main(String[] args) {
	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);
	    new Test(args, groupMaster);
	} catch (CCJException e) {
	    System.err.println("Error in PingPong constructor: " + e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

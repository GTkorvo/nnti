/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;

import java.io.Serializable;

class PingPong extends ColMember {

    private int n;
    private ColGroup group;

    public static int [] sizes = { 1, 16384 };

    void setGroup(ColGroup group) {
        this.group = group;
    }


    PingPong(String[] args, ColGroupMaster groupMaster) throws CCJException {
	super();

	if (args.length != 1) {
	    System.err.println("1 parameters expected: runs\nNumber of arguments entered = "+
		       args.length);
	    for (int i = 0 ; i < args.length ; i++) {
		System.err.println("Arg " + i + " = "+ args[i]);
	    }
	    System.exit(1);
	}

	n = Integer.parseInt(args[0]);

	int numberOfCpus = groupMaster.getNumberOfCpus();

	groupMaster.addMember("myGroup", this);
	group = groupMaster.getGroup("myGroup", numberOfCpus);

	begin();
    }


    public void run() {
        long start, end;
        double time = 0.0;

        try {
            int rank = group.getRank(this);
            int nodes = group.size();

            if (rank == 0) {
                System.out.println("Scatter started, n = " + n + " nodes = " + nodes);
            }

            barrier(group);


            for (int j=1;j<=sizes.length;j++) {

                int current_size = sizes[sizes.length-j];
                IntArray data = new IntArray(current_size*nodes);
                int [] rec;

                if (rank == 0) {

                    barrier(group);

                    // warmup
                    for (int i=0;i<n;i++) {
                        rec = (int []) scatter(group, data, 0);
                    }

                    System.gc();
                    barrier(group);

                    // real test

                    start = System.currentTimeMillis();

                    for (int i=0;i<n;i++) {
                        rec = (int []) scatter(group, data, 0);
                    }

                    barrier(group);

                    end = System.currentTimeMillis();

                    time = end - start;

                    System.out.println("Scatter of " + current_size + " ints/node on " + nodes + " cpus took " + (time / 1000.0) + " secs. -> Latency " + ((time * 1000)/ n) + " usec/call");
                } else {
                    barrier(group);

                    // warmup
                    for (int i=0;i<n;i++) {
                        rec = (int []) scatter(group, data, 0);
                    }

                    System.gc();

                    barrier(group);
                    // real test
                    for (int i=0;i<n;i++) {
                        rec = (int []) scatter(group, data, 0);
                    }
                    barrier(group);
                }
            }
            System.exit(0);
        } catch (CCJException e) {
            System.out.println("Asp.java: Exception: "+ e.toString());
            e.printStackTrace();
            System.exit(1);
        }
    }


    public static void main(String[] args) {
	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);
	    new PingPong(args, groupMaster);
	} catch (CCJException e) {
	    System.err.println("Error in PingPong constructor: " + e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

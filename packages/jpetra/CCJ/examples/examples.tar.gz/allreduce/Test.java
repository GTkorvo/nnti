/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import java.io.*;

import CCJ.*;

class Test extends ColMember {

    private int count;
    ColGroup group;
    ColGroupMaster groupMaster;


    Test(String[] args, ColGroupMaster groupMaster) throws CCJException {
	super();
	this.groupMaster = groupMaster;

	if (args.length != 1) {
	    System.err.println("1 parameters expected: runs\nNumber of arguments entered = "+
		       args.length);
	    for (int i = 0 ; i < args.length ; i++) {
		System.err.println("Arg " + i + " = "+ args[i]);
	    }
	    System.exit(1);
	}

	count = Integer.parseInt(args[0]);

	int numberOfCpus = groupMaster.getNumberOfCpus();

	groupMaster.addMember("myGroup", this);
	group = groupMaster.getGroup("myGroup", numberOfCpus);

	begin();
    }


    public void run() {

	try {
	    SumDoubleReduce sdr = new SumDoubleReduce();

	    int cpu = group.getRank(this);
	    int nodes = group.size();

	    Double value = new Double(1.0);

	    if (cpu == 0) {
		System.out.println("Started Test");
	    }

	    // Wait for the others.
	    barrier(group);

	    long start = System.currentTimeMillis();

	    for (int i=0;i<count;i++) {
		value = (Double) allReduce(group, value, sdr);
	    }

	    // Wait for the others.
	    barrier(group);

	    long end = System.currentTimeMillis();

	    if (cpu == 0) {

		long time   = end - start;
		double usec = 1000.0*time;
		double sec  = time/1000.0;

		System.out.println("----------------------------" +
			   "\nallReduce : " +
			   "\n#seconds  : " + sec +
			   "\n#count    : " + count +
			   "\nallreduce : " + (usec/count) + " usec/allreduce" +
			   "\n----------------------------\n");
	    }

	    // Wait for the others.
	    barrier(group);
	    System.exit(0);

	} catch (CCJException e) {
	    System.out.println("Test : oops, something is wrong !");
	    e.printStackTrace();
	}
    }


    public static void main(String[] args) {
	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);
	    new Test(args, groupMaster);
	} catch (CCJException e) {
	    System.err.println("Error in PingPong constructor: " + e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

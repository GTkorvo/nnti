/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.Serializable;

class DoubleArray implements Partitionable {

    public double array[];
    public int n;

    public DoubleArray(int length) {
	array = new double[length];
	n = length;
    }


    public int size() {
	return array.length;
    }


    public void setElementAt(int index, int groupSize, Serializable object) {

	double [] other = (double []) object;

	int d = n / groupSize;
	int m = n % groupSize;

	int offset = index * d;
	int size = d;

	if (index >= (groupSize - m)) {
	    size += 1;
	    offset += index - (groupSize - m);
	}

	System.arraycopy(other, 0, array, offset, size);
    }


    public Serializable elementAt(int index, int groupSize) {
	int size = array.length / groupSize;
	if ((array.length % groupSize) != 0) {
	    throw new RuntimeException("Unbalanced distribution not supported.");
	}
	double [] other = new double[size];
	int myIndex = index * size;

	System.arraycopy(array, myIndex, other, 0, size);
	return other;
    }


    public String toString() {
	return "DoubleArray([" + array.length + "])";
    }

}

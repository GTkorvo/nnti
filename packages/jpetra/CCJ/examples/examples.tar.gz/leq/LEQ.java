/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import java.io.*;
import CCJ.*;

class LEQ extends ColMember {

    private final double BOUND = 0.001;

    //    DoubleVector x_val;
    private int size, offset, n, cpu, nodes;
    ColGroup group;

    void setGroup(ColGroup group) {
	this.group = group;
    }


    LEQ(int n, int nobjects, ColGroupMaster groupMaster) throws CCJException {
	super();

	this.n = n;
	groupMaster.addMember("myGroup", this);

	int numberOfCpus = groupMaster.getNumberOfCpus();

	group = groupMaster.getGroup("myGroup", numberOfCpus * nobjects);

	begin();
    }


    public void run() {
	try {
	    int phase, i_glob;
	    double residue;

	    double [] b;
	    double [][] a;

	    DoubleArray result_x;
	    double [] new_x, local_x, temp_x;
	    SumDoubleReduce sdr = new SumDoubleReduce();
	    Double result;

	    phase = 0;

	    cpu = group.getRank(this);
	    nodes = group.size();

	    int d = n / nodes;
	    int m = n % nodes;

	    offset = cpu * d;
	    size = d;

	    if (cpu >= (nodes - m)) {
		size += 1;
		offset += cpu - (nodes - m);
	    }

	    System.out.println("Started LEQ on " + cpu + " offset " +
		       offset + " size " + size);

	    a = new double[size][n];
	    b = new double[size];

	    new_x = new double[size];
	    local_x = new double[n];
	    //new_x = new DoubleArray(size);
	    //local_x = new DoubleArray(n);
	    result_x = new DoubleArray(n);

	    //for (int i = 0; i < n; i++) {
	    //    local_x[i] = result_x.array[i] = 0.0;
	    //}

	    // Initialize the local data.

	    for (int j = 0; j < size; j++) {
		for (int k = 0; k < n; k++) {
		    a[j][k] = 1.0;
		}
		a[j][offset + j] = (double) n;
		b[j] = 1.0;
	    }

	    // Wait for the others.
	    barrier(group);

	    // Start the calculation.
	    System.out.println("LEQ " + cpu + ": starting calculation.");

	    long start = System.currentTimeMillis();

	    do {
		residue = 0.0;
		phase++;

		temp_x = local_x;
		local_x = result_x.array;
		result_x.array = temp_x;

		for (int i = 0; i < size; i++) {

		    i_glob = i + offset;
		    new_x[i] = b[i];

		    for (int j = 0; j < i_glob; j++) {
			new_x[i] -= a[i][j] * local_x[j];
		    }

		    for (int j = i_glob + 1; j < n; j++) {
			new_x[i] -= a[i][j] * local_x[j];
		    }

		    new_x[i] = new_x[i] / a[i][i_glob];
		    residue += Math.abs(new_x[i] - local_x[i_glob]);
		}


		if (nodes > 1) {
		    allGather(group, result_x, new_x);
		    result = (Double) allReduce(group, new Double(residue), sdr);
		} else {
		    temp_x = new_x;
		    new_x = result_x.array;
		    result_x.array = temp_x;
		    result = new Double(residue);
		}

	    } while (result.doubleValue() >= BOUND);

	    // Wait for the others.
	    barrier(group);

	    long end = System.currentTimeMillis();

	    System.out.println("LEQ " + cpu + ": finished calculation." + phase);

	    if (cpu == 0) {
		double checksum = 0.0;

		for (int i = 0; i < n; i++) {
		    checksum += result_x.array[i];
		}

		System.out.println("----------------------------" +
			   "\n#seconds : " + ((end - start) / 1000.0) +
			   "\n#phases  : " + phase + "\nresult   : " +
			   result.doubleValue() + "\nchecksum : " +
			   checksum + "\n----------------------------\n");

	    }

	    System.exit(0);


	} catch (CCJException e) {
	    System.out.println("LEQ " + cpu + ": oops, something is wrong !");
	    e.printStackTrace();
	}
    }


    public static void main(String[] args) {
	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);

	    if (args.length != 2) {
		System.err.println("2 parameters expected: <threads> <N>\nNumber of arguments entered = "+
			   args.length);
		for (int i = 0 ; i < args.length ; i++) {
		    System.err.println("Arg " + i + " = "+ args[i]);
		}

		System.exit(1);
	    }

	    int nobjects = Integer.parseInt(args[0]);
	    int N = Integer.parseInt(args[1]);

	    LEQ myMembers[] = new LEQ[nobjects];

	    for (int i = 0 ; i < nobjects; i++) {
		new LEQ(N, nobjects, groupMaster);
	    }

	} catch (CCJException e) {
	    System.err.println("Error in LEQ main(): " + e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

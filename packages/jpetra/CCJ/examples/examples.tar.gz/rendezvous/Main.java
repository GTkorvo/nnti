/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;

class Main {

    public static void main (String args[]) {

	ColGroup group = null;
	int N = 0;
	int max_size = 16384;

	if (args.length == 2) {
	    max_size = Integer.parseInt(args[1]);
	} else if (args.length != 1) {
	    System.err.println("1 parameter expected: <N> \nNumber of arguments entered = " + args.length);
	    for (int i = 0 ; i < args.length ; i++) {
		System.err.println("Arg " + i + " = "+ args[i]);
	    }
	    System.exit(1);
	}

	try {
	    N = Integer.parseInt(args[0]);
	} catch (NumberFormatException e) {
	    System.err.println("Number format error: " + args[0] + "; " + e);
	    System.exit(1);
	}

	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);
	    int numberOfCpus = groupMaster.getNumberOfCpus();

	    if (numberOfCpus != 2) {
		System.err.println("Need exactly 2 cpus.");
		System.exit(1);
	    }

	    PingPong pp = new PingPong(N, max_size);
	    groupMaster.addMember("myGroup", pp);
	    group = groupMaster.getGroup("myGroup",numberOfCpus);
	    pp.setGroup(group);
	    pp.begin();

	} catch (CCJException e) {
	    System.err.println("Error in Main "+e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

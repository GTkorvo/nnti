/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;

import java.io.Serializable;

class PingPong extends ColMember {

    private int n;
    private int max_size = 16384;
    private ColGroup group;
    private int rank;


    void setGroup(ColGroup group) {
	this.group = group;
    }


    PingPong(int n, int max_size) throws CCJException {
	super();
	this.n = n;
	this.max_size = max_size;
    }


    PingPong(int n) throws CCJException {
	super();
	this.n = n;
    }


    private void ping_pong(Serializable data, int n)
	    throws CCJException {
	for (int i=0;i<n;i++) {
	    //receive(group, 0);
	    //send_async(group, data, 0);
	    rendezVous(group, data, 1 - rank);
	}
    }


    public void run() {
	long start, end;
	double time = 0.0;

	int n_size = 0;
	for (int s = max_size; s != 0; s /= 2, n_size++) {
	    /* count */
	}
	n_size++;

	int[] sizes = new int[n_size];
	int s = max_size;
	for (int i = 0; i < n_size; i++, s /= 2) {
	    sizes[i] = s;
	}

	try {
	    rank = group.getRank(this);
	    int nodes = group.size();

	    if (rank == 0) {
		System.out.println("rendezVous started, n = " + n);
	    }

	    for (int j = 0; j < sizes.length; j++) {

		int current_size = sizes[j];
		int[] data;
		if (current_size == 0) {
		    data = null;
		} else {
		    data = new int[sizes[j]];
		}

		if (rank == 0) {
		    System.out.print("Warmup int[" + current_size + "] ... ");
		    System.out.flush();
		}
		System.gc();
		barrier(group);

		// warmup
		ping_pong(data, n);

		// real test

		if (rank == 0) {
		    System.out.print("Measure int[" + current_size + "] ... ");
		    System.out.flush();
		}

		System.gc();
		barrier(group);

		start = System.currentTimeMillis();

		ping_pong(data, n);

		end = System.currentTimeMillis();

		time = end - start;

		if (rank == 0) {
		    System.out.println();
		    System.out.print("rendezVous int[" + current_size + "] took " + (time / 1000.0) + " s.");
		    System.out.println("Per roundtrip " + ((time * 1000)/ n) + " us; one-sided " + ((time * 500) / n) + " us");
		}
	    }

	    System.exit(0);

	} catch (CCJException e) {
	    System.out.println("Asp.java: Exception: "+ e.toString());
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

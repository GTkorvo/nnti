/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;
import java.io.Serializable;

class SumIntArray implements Reducible {

    public Serializable reduce(Serializable obj1, Serializable obj2) {
	int [] a1 = (int []) obj1;
	int [] a2 = (int []) obj2;

	for (int i=0;i<a1.length;i++) {
	    a1[i] += a2[i];
	}

	return a1;
    }

}

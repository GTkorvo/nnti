/*
 * Copyright 2001 Vrije Universiteit, The Netherlands.
 * For full copyright and restrictions on use see the file COPYRIGHT in the
 * top level of the CCJ distribution.
 */

import CCJ.*;

import java.io.Serializable;

class PingPong extends ColMember {

    private int n = 1000;
    private int max_size = 16384;
    private ColGroup group;
    private int rank;
    private ColGroupMaster groupMaster;
    private static final String groupName = "myGroup";


    PingPong(int n, int max_size) throws CCJException {
	super();
	this.n = n;
	this.max_size = max_size;
    }


    PingPong(int n) throws CCJException {
	super();
	this.n = n;
    }


    PingPong(String[] args, ColGroupMaster groupMaster) throws CCJException {

	this.groupMaster = groupMaster;

	int numberOfCpus = groupMaster.getNumberOfCpus();

	if (numberOfCpus != 2) {
	    System.err.println("Need exactly 2 cpus.");
	    System.exit(1); 
	}

	groupMaster.addMember(groupName, this);
	group = groupMaster.getGroup("myGroup",numberOfCpus);

	int option = 0;
	for (int i = 0; i < args.length; i++) {
	    if (false) {
	    } else if (option == 0) {
		try {
		    n = Integer.parseInt(args[i]);
		} catch (NumberFormatException e) {
		    System.err.println("Not a number: \"" + args[i] + "\"");
		    System.exit(1);
		}
		option++;
	    } else if (option == 1) {
		try {
		    max_size = Integer.parseInt(args[i]);
		} catch (NumberFormatException e) {
		    System.err.println("Not a number: \"" + args[i] + "\"");
		    System.exit(1);
		}
		option++;
	    }
	}

	begin();
    }


    private void server(Serializable data, int n) throws CCJException {
	for (int i = 0; i < n; i++) {
	    send_async(group, data, 1 - rank);
	    receive(group, 1 - rank);
	}
    }


    private void client(Serializable data, int n) throws CCJException {
	for (int i = 0; i < n; i++) {
	    receive(group, 1 - rank);
	    send_async(group, data, 1 - rank);
	}
    }


    public void run() {
	long start, end;
	double time = 0.0;

	int n_size = 0;
	for (int s = max_size; s != 0; s /= 2, n_size++) {
	    /* count */
	}
	n_size++;

	int[] sizes = new int[n_size];
	int s = max_size;
	for (int i = 0; i < n_size; i++, s /= 2) {
	    sizes[i] = s;
	}

	try {
	    rank = group.getRank(this);
	    int nodes = group.size();

	    if (rank == 0) {
		System.out.println("PingPong started, n = " + n);
	    }

	    for (int j = 0; j < sizes.length; j++) {

		int current_size = sizes[j];
		int[] data;
		if (current_size == 0) {
		    data = null;
		} else {
		    data = new int[sizes[j]];
		}

		if (rank == 0) {

		    System.out.print("Warmup int[" + current_size + "] ... ");
		    System.out.flush();
		    barrier(group);

		    // warmup
		    server(data, n);

		    System.out.print("Measure int[" + current_size + "] ... ");
		    System.out.flush();
		    System.gc();
		    barrier(group);

		    // real test

		    start = System.currentTimeMillis();

		    server(data, n);

		    end = System.currentTimeMillis();

		    time = end - start;

		    System.out.println();
		    System.out.println("PingPong of int[" + current_size + "] took " + (time / 1000.0) + "s. Per roundtrip " + ((time * 1000)/ n) + " us; one-sided " + ((time * 500) / n) + " us");

		} else {
		    barrier(group);

		    // warmup
		    client(data, n);

		    System.gc();

		    barrier(group);
		    // real test
		    client(data, n);
		}
	    }
	    groupMaster.deleteMember(groupName, this);
	    System.exit(0);
	} catch (CCJException e) {
	    System.out.println("Asp.java: Exception: "+ e.toString());
	    e.printStackTrace();
	    System.exit(1);
	}
    }


    public static void main(String[] args) {
	try {
	    ColGroupMaster groupMaster = new ColGroupMaster(args);
	    new PingPong(args, groupMaster);
	} catch (CCJException e) {
	    System.err.println("Error in PingPong constructor: " + e);
	    e.printStackTrace();
	    System.exit(1);
	}
    }

}

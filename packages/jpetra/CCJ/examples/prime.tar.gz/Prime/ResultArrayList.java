/*
 * PrimeCCJTest.java
 *
 * Created on June 10, 2003, 6:36 PM
 */

package Prime;

import java.util.*;  // for the ArrayList
import java.io.Serializable;

import CCJ.*;

/**
 * Used by CCJ to compile all the results together during a gatherAll call.
 * Implements the CCJ interface Partitionable.
 *
 * @author Jason Cross
 */
 
public class ResultArrayList implements Partitionable {
    
    /**
     * holds the total results from all processes
     */
    private ArrayList results;
    
    /**
     * holds the end index offset for the results from each process
     */
    private int[] offsets;
    
    /**
     * Creates a new ResultArrayList.
     * 
     * @param groupSize number of processes in the group
     */
    public ResultArrayList (int groupSize) {
        offsets = new int[groupSize];
        results = new ArrayList();
    }
    
    /**
     * Used internally by CCJ.
     *
     * @param index process ID or rank
     * @param groupSize number of processes in the group
     * @param object passed by process ID or rank
     */
    public void setElementAt(int index, int groupSize, Serializable object) {
        ArrayList input = (ArrayList) object;  // cast object into something usefull;
        
        // add each element of input to results
        for(int i=0; i < input.size(); i++) {
            results.add(input.get(i));
        }
        
        offsets[index] = input.size(); // set the end index offset for input in results
    }
    
    /**
     * Used internally by CCJ.
     *
     * @param index process ID or rank
     * @param groupSize number of processes in the group
     * @return ArrayList from process with this <code>index</code>
     */
    public Serializable elementAt(int index, int groupSize) {
        int indexOffset = 0;  // start the index offset at 0
        
        // add up the total number of offsets before index's offset to find where to start at
        for(int i=0; i < index; i++) {
            indexOffset += offsets[i];
        }
        
        // will be returned
        ArrayList elementResult = new ArrayList();
        
        // start at indexOffset and add all the elements until the end of index's end offset
        // note that this is the reverse of setElementAt
        for(int i=indexOffset; i < offsets[index]; i++) {
            elementResult.add(results.get(i));
        }
        
        return elementResult;
    }

    /**
     * Returns an ArrayList of all the results.
     *
     * @return all arrays from all proceses put in order by process into one <code>ArrayList</code>
     */
    public ArrayList returnArrayList () {
        return results;
    }    
}

/*
 * PrimeTest.java
 *
 * Created on June 10, 2003, 6:36 PM
 */

package Prime;

import java.io.*;
import java.util.*;  // for ArrayList

/**
 * Tests the PrimeGenerate class and prints the result;  uses one process.
 *
 * @author Jason Cross
 */
public class PrimeTest {

    /**
     * Creates a new <code>PrimeTest</code> then finds and prints the
     * prime numbers from <code>start</code> to <code>end</code>.
     *
     * @param start integer index to start finding primes at
     * @param end integer index to stop finding primes at
     */
    PrimeTest (int start, int end) {
        ArrayList results = new PrimeGenerate(start,end).go();
        for(int i=0; i < results.size(); i++) {
            System.out.println((Integer) results.get(i));
        }
    }
    
    /**
     * Finds prime numbers between 100000 and 200000.
     */
    public static void main (String args[]) {
        new PrimeTest(100000,200000);  
    }
}
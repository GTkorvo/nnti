/*
 * PrimeCcjTest.java
 *
 * Created on June 10, 2003, 6:36 PM
 */

package Prime;

import java.io.*;
import java.util.*;  // needed for ArrayList

import CCJ.*;

/**
 * Test class that uses the classes <code>PrimeGenerate</code> and <code>ResultArrayList</code>
 * in order to demonstrate and document
 * some of the message passing abilities of CCJ;  multiple process capibility.
 *
 * @author  Jason Cross
 */
public class PrimeCcjTest2 extends ColMember {

    /**
     * process group, all processes belong to the same group
     */
    private ColGroup group;
    
    /**
     * root process
     */
    private ColGroupMaster groupMaster;
    

     /**
      * Creates a new PrimeCcjTest and calls the run() method.
      */
    PrimeCcjTest2(String[] args, ColGroupMaster groupMaster) throws CCJException {
        super();
        this.groupMaster = groupMaster;
        
	    int numberOfCpus = groupMaster.getNumberOfCpus();
        
        // notice that the group name is a string
        groupMaster.addMember("myGroup", this);
	    group = groupMaster.getGroup("myGroup", numberOfCpus);

        // calls the run method
	    //begin();
	    go();
    }
    
    public void run() {
        System.out.println("I ran...?");
    }
    
    /**
     * Contains the main body of code executed
     */
    public void go() {
    
        /**
         * start index for generating prime numbers, hard coded for 2 processes
         */
        int [] start = new int[2];
        
        /**
         * end index for generating prime numbers, hard coded for 2 processes
         */
        int [] end = new int[2];
        
        /**
         * initially set to -1
         */
        int process = -1;
        
        try {
            process = group.getRank(this);  // get rank or process id
            int processes = group.size();   // get the number of processes
	        
	        System.out.println("Waiting for others...");
	        
	        // waits for all other processes
	        barrier(group);
	        
	        // root cpu assigns start and end indexes
	        if (process == 0) {
	            start[0]=1000; start[1]=50000;
	            end[0]=49999; end[1]=100000;
	        }
	        
	        // identifies which terminal is which process and confirm they are different
	        System.out.println("Ok, everyone is up.\nI'm process #" + process + " out of " + processes + " processes!");
	        
	        barrier(group);

            // broadcasts the start and ending indexes
	        start = (int[]) broadcast(group, start, 0);
	        
	        // note that the last value 0 is the id of the root process
	        end = (int[]) broadcast(group, end, 0);
	        
	        System.out.println("Broadcast done");
	        
	        barrier(group);
	        
	        // print out the result of the broadcast
	        System.out.println("array info: " + start[process] + " " + end[process]);
	        
	        // generates some prime numbers
	        ArrayList primes = new PrimeGenerate(start[process],end[process]).go(); 
	        
	        // prints the number of primes found
	        System.out.println("my array size: " + primes.size());
	        
	        // initializes the ResultArrayList with the number of processes
	        ResultArrayList result = new ResultArrayList(group.size());
	        
	        // gathers all the prime numbers found into each process stored in the result object
	        allGather(group, result, primes);
	        
	        barrier(group);
	        
	        // gets the ArrayList of all the primes
	        ArrayList result_array_list = result.returnArrayList();
	        
	        // print out the total number of primes found
	        System.out.println("total array size: " + result_array_list.size());
	        
	        System.out.println("All done, bye bye!");
	        
	        // done
	        System.exit(0);
	        	        
	    } catch (CCJException e) {
	        System.err.println("Something bad happened: " + e);  // Catch any exceptions
	    }
    }
    
    /**
     * Calls the contructor for a new <code>PrimeCcjTest</code>
     */
    public static void main(String[] args) {
        
        // All code for main was taken from a CCJ example
        try {
            // note the arguments passed to a CCJ program must be the same for each process
            ColGroupMaster groupMaster = new ColGroupMaster(args);
            new PrimeCcjTest2(args, groupMaster);
        } 
        catch (CCJException e) {
            System.err.println("Error in CCJTest constructor: " + e);
            
            // CCJ author recommended exiting all CCJ programs with exit(1) since programs using the RMI don't like to quit
            System.exit(1);
        }
    }
}
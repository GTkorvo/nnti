/*
 * PrimeGenerate.java
 *
 * Created on June 10, 2003, 6:36 PM
 */

package Prime;

import java.util.*;  // needed for ArrayList


/**
 * Finds prime numbers from the integers <code>start</code> to <code>end</code>.
 * Uses a simple prime number generator algorythm.
 *
 * @author Jason Cross
 */
public class PrimeGenerate {
    /**
     * integer index to start finding primes at
     */
    private int start;
    
    /**
     * integer index to stop finding primes at
     */
    private int end;

    /**
     * Creates a new <code>PrimeGenerate</code> and sets <code>start</code> and <code>end</code>.
     *
     * @param start integer to start at, sets this.start
     * @param end integer to end at, sets this.start
     */
    public PrimeGenerate (int start, int end) {
        this.start = start;
        this.end = end;
    }
    
    /**
     * Does the actual computation to find prime numbers.
     *
     * @return ArrayList of Integers
     */
    public ArrayList go () {
        ArrayList results = new ArrayList();  // holds all the prime numbers found
        boolean isPrime;  // is true when the integer being tested is a prime
        
        // find the prime numbers
        for (int i=start; i <= end; i++) {
            // reset is_prime
            isPrime=true;
            
            for (int j=2; j*j < i; j++) {
                // if there is no remainder then i is not a prime
                if ((i % j) == 0) {
                    isPrime=false;
                    break;
                }
            }
            
            // i must be an Integer to be put in an ArrayList
            if (isPrime) {results.add(new Integer(i));}
        }

    return results;
    }
}
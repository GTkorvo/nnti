/**************************************************************************
*                                                                         *
*             Java Grande Forum Benchmark Suite - MPJ Version 1.0         *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         *
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*      adapted from SciMark 2.0, author Roldan Pozo (pozo@cam.nist.gov)   *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/

package section2.sor;

import jgfutil.*;
import CCJ.*;

public abstract class SOR extends ColMember {

	public int nprocess;
	public int rank;
	public int p_row;
//	public int ref_p_row;
//	public int rem_p_row;

	public double Gtotal = 0.0;

	ColGroup group;

	SOR(int nprocess) throws Exception { 
		this.nprocess = nprocess;
	}

	void setGroup(ColGroup group) throws Exception {
		this.group = group;
		rank = group.getRank(this);
	}
	
	public final void SORrun(double omega, double p_G[][], int num_iterations) throws Exception {

		int M = p_G.length;
		int N = p_G[0].length;

		double omega_over_four = omega * 0.25;
		double one_minus_omega = 1.0 - omega;

		int ilow,ihigh;
		int rm_length;

		// update interior points
		//
		int Mm1 = M-1;
		int Nm1 = N-1;

		ilow = 0;
		ihigh = Mm1 + 1;

		//MPI.COMM_WORLD.Barrier();
		barrier(group);

		if(rank==0) {
			JGFInstrumentor.startTimer("Section2:SOR:Kernel");
		}

		for (int p=0; p<2*num_iterations; p++) {
			for (int i=ilow+(p%2); i<ihigh; i=i+2) {

				if(i!=0) {
					double [] Gi = p_G[i];
					double [] Gim1 = p_G[i-1];

					if((i==1)&&rank==0) {
					}
					else if((i==ihigh-1)&&rank==(nprocess-1)) {
					}
					else if(((i==2)&&rank==0)||((i==1)&&(rank!=0))) {

						double [] Gip1 = p_G[i+1];

						for (int j=1; j<Nm1; j=j+2) {
							Gi[j] = omega_over_four * (Gim1[j] + Gip1[j] + Gi[j-1] + Gi[j+1]) + one_minus_omega * Gi[j];
						}
					} else if (((i==ihigh-2)&&rank==(nprocess-1))|| ((i==ihigh-1)&&(rank!=(nprocess-1)))) {
						double [] Gim2 = p_G[i-2];

						for (int j=1; j<Nm1; j=j+2) {
							if((j+1) != Nm1) {
								Gim1[j+1]=omega_over_four * (Gim2[j+1] + Gi[j+1] + Gim1[j] + Gim1[j+2]) + one_minus_omega * Gim1[j+1];
							}
						}

					} else {
						double [] Gip1 = p_G[i+1];
						double [] Gim2 = p_G[i-2];

						for (int j=1; j<Nm1; j=j+2) {
							Gi[j] = omega_over_four * (Gim1[j] + Gip1[j] + Gi[j-1] + Gi[j+1]) + one_minus_omega * Gi[j];

							if((j+1) != Nm1) {
								Gim1[j+1]=omega_over_four * (Gim2[j+1] + Gi[j+1] + Gim1[j] + Gim1[j+2]) + one_minus_omega * Gim1[j+1];
							}
						}
					}


				}

			}

			/* Do the halo swaps */

			if (rank!=nprocess-1) {
				//MPI.COMM_WORLD.Sendrecv(p_G[p_G.length-2],0,p_G[p_G.length-2].length,MPI.DOUBLE, rank+1,1, p_G[p_G.length-1],0, p_G[p_G.length-1].length,MPI.DOUBLE,rank+1,2);
				p_G[p_G.length-1] = (double[])send_receive(group, p_G[p_G.length-2], rank+1, group, rank+1);
			}

			if (rank!=0) {
				//MPI.COMM_WORLD.Sendrecv(p_G[1],0,p_G[1].length,MPI.DOUBLE,rank-1,2, p_G[0],0,p_G[0].length,MPI.DOUBLE,rank-1,1);
				p_G[0] = (double[])send_receive(group, p_G[1], rank-1, group, rank-1);
			}

		}

		if(rank==0) {
			JGFInstrumentor.stopTimer("Section2:SOR:Kernel");
		}
	}
}


/**************************************************************************
*                                                                         *
*             Java Grande Forum Benchmark Suite - MPJ Version 1.0         *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         * 
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/


package section2.sor;

import java.io.Serializable;
import jgfutil.*;
import java.util.Random;
import CCJ.*;

public class JGFSORBench extends SOR implements JGFSection2 {

	private static int size;
	private int datasizes[]={1000,1500,2000};

	private static final int JACOBI_NUM_ITER = 100;
	private static final long RANDOM_SEED = 10101010;

	double [][] p_G = null;
	int m_size,n_size,m_length;

	Random R = new Random(RANDOM_SEED);

	public JGFSORBench(int nprocess) throws Exception {
		super(nprocess);
	}

	public void JGFsetsize(int size) {
		//this.size = size; no-op
	}

	public void JGFinitialise() {
	}

	public void JGFkernel() throws Exception {

		int iup = 0;
		double G[][] = null; 
			
		/* create the array G on process 0 */

		if(rank==0) {
			m_size = datasizes[size];
			n_size = datasizes[size];
			G = RandomMatrix(m_size, n_size, R);
		} else {
			m_size = 0;
			n_size = 0;
		}
	
		/* create the sub arrays of G */

// THIS IS WRONG !!
//              p_row = (((datasizes[size] / 2) + nprocess -1) / nprocess)*2;
//  		ref_p_row = p_row;
//  		rem_p_row = p_row - ((p_row*nprocess) - datasizes[size]);

//  		if(rank==(nprocess-1)) {
//  			if((p_row*(rank+1)) > datasizes[size]) {
//  				p_row = rem_p_row;
//  			}
//  		}

		int worksize   = datasizes[size] / nprocess;
		int leftovers  = datasizes[size] % nprocess;
		int extra_work = nprocess - leftovers;

		if (rank >= extra_work) { 
			worksize++;			
		} 		

		p_row = worksize;

		//p_G = new double [p_row+2][datasizes[size]];

		/* copy or send the values of G to the sub arrays p_G */

		if(rank==0) {			

			p_G = new double[p_row+2][datasizes[size]];

			if(nprocess==1) {
				iup = p_row+1;
			} else {
				iup = p_row+2;
			}

			for(int i=1;i<iup;i++) {
				for(int j=0;j<p_G[0].length;j++) {
					p_G[i][j] = G[i-1][j];
				}
			}

			//for(int j=0;j<G[0].length;j++) {
			//	p_G[0][j] = 0.0;
			//}

			double temp [][] = null;

			int start = worksize;			
											
			for(int k=1;k<nprocess;k++) {
			
				if (k >= extra_work) { 
					m_length = worksize + 1;
				} else { 
					m_length = worksize;
				}

				if (k == (nprocess-1)) { 
					m_length += 1;
				} else { 
					m_length += 2;
				}

				//if (k==nprocess-1) {
				//	m_length = rem_p_row + 1;
				//} else {
				//	m_length = p_row + 2;
				//}
			
				if (temp == null || temp.length != m_length) { 
					temp = new double[m_length][];
				}

				//for (int aap=0;aap<m_length;aap++) {
				//	temp[aap] = G[(k*p_row)-1+aap];
				//}
				System.arraycopy(G, start-1, temp, 0, m_length);

				//MPI.COMM_WORLD.Send(G,(k*p_row)-1,m_length,MPI.OBJECT,k,k);
				send_async(group, (Serializable)temp, k);

				if (k >= extra_work) { 
					start += (worksize + 1);
				} else { 
					start += size;
				}
			}

		} else {
			//MPI.COMM_WORLD.Recv(p_G,0,p_row+2,MPI.OBJECT,0,rank);
			double [][] temp = (double[][]) receive(group, 0);

			if (rank==(nprocess-1)) {
				
				p_G = new double[p_row+2][];
				System.arraycopy(temp, 0, p_G, 0, temp.length);
				p_G[p_G.length-1] = new double[datasizes[size]];

				//for(int j=0;j<datasizes[size];j++) {
				//	p_G[p_G.length-1][j] = 0.0;
				//}
			} else { 
				p_G = temp;
			}
		}

		//MPI.COMM_WORLD.Barrier();
		barrier(group);

//		System.gc();
		SORrun(1.25, p_G, JACOBI_NUM_ITER);
		
		/* Send all data back to G */

		//MPI.COMM_WORLD.Barrier();
		//System.gc();

		if (rank == 0) {

			for(int i=1;i<p_G.length-1;i++) {
				for(int j=0;j<p_G[i].length;j++) {
					G[i-1][j] = p_G[i][j];
				}
			}

			double [][] buffer = null;

			int start = worksize;		

			for(int k=1;k<nprocess;k++) {							

				//if ( k==(nprocess-1) ) {
				//	rm_length = rem_p_row;
				//} else {
				//rm_length = p_row;
				//}

				if (k >= extra_work) { 
					m_length = worksize + 1;
				} else { 
					m_length = worksize;
				}

//				System.out.println(rank + " receiving from " + k);

				//MPI.COMM_WORLD.Recv(G,k*p_row,rm_length,MPI.OBJECT,k,k);
				buffer = (double[][]) receive(group, k);

				//for (int i = 0;i<buffer.length;i++) { 
				//	G[k*p_row+i] = buffer[i];
				//}
				System.arraycopy(buffer, 0, G, start, buffer.length);
				//System.gc();
				
				if (k >= extra_work) { 
					start += (worksize + 1);
				} else { 
					start += size;
				}
			}
		} else {
//			for(int k=1;k<nprocess;k++) {
//				if(rank==k) {
//			System.out.println(rank + " sending to 0");
			
			//MPI.COMM_WORLD.Ssend(p_G,1,p_row,MPI.OBJECT,0,rank);
			double [][] buffer = new double[p_row][];					
			
			//for (int aap=0;aap<p_row;aap++) { 
			//	buffer[aap] = p_G[1+aap];
			//}
			System.arraycopy(p_G, 1, buffer, 0, p_row);
			send_sync(group, buffer, 0);
//				}
//			}
		}

		//MPI.COMM_WORLD.Barrier();
		barrier(group);
	
		/* Determine Gtotal on process 0 */

		if(rank==0) {
			for (int i=1; i<G.length-1; i++) {
				for (int j=1; j<G[0].length-1; j++) {
					Gtotal += G[i][j];
				}
			}
		}


	}

	public void JGFvalidate() {

		//    double refval[] = {0.4984199298207158,1.123010681492097,1.9967774998523777};
		double refval[] = {0.498574406322512,1.1234778980135105,1.9954895063582696};

		if(rank==0) {
			double dev = Math.abs(Gtotal - refval[size]);

			if (dev > 1.0e-12 ) {
				System.out.println("Validation failed");
				System.out.println("Gtotal = " + Gtotal + "  " + dev + "  " + size);
			}
		}
	}

	public void JGFtidyup() {
//		System.gc();
	}

	public void JGFrun(int size) throws Exception {

		if(rank==0) {
			JGFInstrumentor.addTimer("Section2:SOR:Kernel", "Iterations",size);
		}

		JGFsetsize(size);
		JGFinitialise();
		JGFkernel();
		JGFvalidate();
		JGFtidyup();

		if(rank==0) {
			JGFInstrumentor.addOpsToTimer("Section2:SOR:Kernel", (double) (JACOBI_NUM_ITER));
			JGFInstrumentor.printTimer("Section2:SOR:Kernel");
		}
	}

	private double[][] RandomMatrix(int M, int N, java.util.Random R) {
		double A[][] = new double[M][N];

		for (int i=0; i<N; i++)
			for (int j=0; j<N; j++) {
				A[i][j] = R.nextDouble() * 1e-6;
			}

		return A;
	}

	public void run() { 
		
		try { 
			JGFrun(size);
			System.exit(0);
		} catch (Exception e) { 
			System.err.println("Error in Run "+e);
			e.printStackTrace();
			System.exit(1);
		} 
	}

	public static void main(String[] args) throws Exception{
		
                /* Initialise CCJ */
		ColGroupMaster groupMaster = new ColGroupMaster(args);
		int nprocess = groupMaster.getNumberOfCpus();
		
		try {
			if (args.length < 1) { 
				size = 0;
			} else { 
				size = Integer.parseInt(args[0]);
				if (size < 0 || size > 2) { 
					throw new Exception("Invalid option " + size);
				}
			}

			JGFSORBench bc = new JGFSORBench(nprocess);
			groupMaster.addMember("myGroup", bc);
			ColGroup group = groupMaster.getGroup("myGroup", nprocess);
			bc.setGroup(group);

			if (group.getRank(bc) == 0) { 
				JGFInstrumentor.printHeader(2,size,nprocess);
			}

			bc.begin();
						
		} catch (Exception e) {
			System.err.println("Error in Main "+e);
			e.printStackTrace();
			System.exit(1);
		}		
	}



}



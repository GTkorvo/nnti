package section2.sparsematmult;

import CCJ.*;
import java.io.Serializable;

class AddDoubleArray implements Reducible {

	double [] result;

//	native void DebugInterface(Serializable s);
//	native void DebugObj(Object o);

	AddDoubleArray(int size) { 
		result = new double[size];
	} 

	public Serializable reduce(Serializable obj1, Serializable obj2) { 

//		DebugInterface(obj1);
//		DebugInterface(obj2);
		
		double [] a1 = (double []) obj1;
		double [] a2 = (double []) obj2;		

//		DebugObj(a1);
//		DebugObj(a2);

		for (int i=0;i<a1.length;i++) { 
			result[i] = a1[i] + a2[i];
		} 

//		Serializable ret = (Serializable) result;
//		return ret;

		return result;
	} 
}



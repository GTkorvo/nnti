/**************************************************************************
*                                                                         *
*             Java Grande Forum Benchmark Suite - MPJ Version 1.0         *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         * 
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/


package section2.crypt;
import jgfutil.*;
import CCJ.*;

public class JGFCryptBench extends IDEATest implements JGFSection2 {

	private static int size;
	private int datasizes[] = { 3000000, 20000000, 50000000 };

	public JGFCryptBench(int nprocess) throws Exception {
		super(nprocess);
	}

	public void JGFsetsize(int size) {
		//this.size = size;
		// no-op
	}

	public void JGFinitialise() {
		array_rows = datasizes[size];

		/* determine the array dimension size on each process
		   p_array_rows will be smaller on process (nprocess-1).
		   ref_p_array_rows is the size on all processes except process (nprocess-1),
		   rem_p_array_rows is the size on process (nprocess-1).
		*/

		p_array_rows = (((array_rows / 8) + nprocess -1) / nprocess)*8;
		ref_p_array_rows = p_array_rows;
		rem_p_array_rows = p_array_rows - ((p_array_rows*nprocess) - array_rows);

		if(rank==(nprocess-1)) {
			if((p_array_rows*(rank+1)) > array_rows) {
				p_array_rows = rem_p_array_rows;
			}
		}

		buildTestData();
	}

	public void JGFkernel() throws Exception {
		Do();
	}

	public void JGFvalidate() {
		boolean error;

		if(rank==0) {
			error = false;

			for (int i = 0; i < array_rows; i++) {
				error = (plain1 [i] != plain2 [i]);

				if (error) {
					System.out.println("Validation failed");
					System.out.println("Original Byte " + i + " = " + plain1[i]);
					System.out.println("Encrypted Byte " + i + " = " + crypt1[i]);
					System.out.println("Decrypted Byte " + i + " = " + plain2[i]);
					//break;
				}

			}

		}

	}

	public void JGFtidyup() {
		freeTestData();
	}

	public void JGFrun(int size) throws Exception {

		if(rank==0) {
			JGFInstrumentor.addTimer("Section2:Crypt:Kernel", "Kbyte", size);
		}

//		System.out.print("setsize " + rank);
		JGFsetsize(size);
//		System.out.print("init " + rank);
		JGFinitialise();
//		System.out.print("kernel " + rank);
		JGFkernel();
//		System.out.print("validate " + rank);
		JGFvalidate();
//		System.out.print("tidy " + rank);
		JGFtidyup();

		if(rank==0) {
			JGFInstrumentor.addOpsToTimer("Section2:Crypt:Kernel", (2*array_rows)/1000.);
			JGFInstrumentor.printTimer("Section2:Crypt:Kernel");
		}
	}

	public void run() { 
		
		try { 
			JGFrun(size);
			System.exit(0);
		} catch (Exception e) { 
			System.err.println("Error in Run "+e);
			e.printStackTrace();
			System.exit(1);
		} 
	}

	public static void main(String[] args) throws Exception{
		
                /* Initialise CCJ */
		ColGroupMaster groupMaster = new ColGroupMaster(args);
		int nprocess = groupMaster.getNumberOfCpus();
		
		try {
			if (args.length < 1) { 
				size = 0;
			} else { 
				size = Integer.parseInt(args[0]);
				if (size < 0 || size > 2) { 
					throw new Exception("Invalid option " + size);
				}
			}

//			System.out.println("Size = " + size);

			JGFCryptBench bc = new JGFCryptBench(nprocess);
			groupMaster.addMember("myGroup", bc);
			ColGroup group = groupMaster.getGroup("myGroup", nprocess);
			bc.setGroup(group);

			if (group.getRank(bc) == 0) { 
				JGFInstrumentor.printHeader(2,size,nprocess);
			}

			bc.begin();
						
		} catch (Exception e) {
			System.err.println("Error in Main "+e);
			e.printStackTrace();
			System.exit(1);
		}		
	}
}

package section3.moldyn;

import CCJ.*;
import java.io.Serializable;

class ReduceData implements Serializable, Reducible { 

	double [] xforce, yforce, zforce;
	double epot;
	double vir;
	int interactions;

	public ReduceData(int size) { 
		xforce = new double[size];
		yforce = new double[size];
		zforce = new double[size];
	} 

	public Serializable reduce(Serializable obj1, Serializable obj2) { 

		ReduceData d1 = (ReduceData) obj1;
		ReduceData d2 = (ReduceData) obj2;
		
		for (int i=0;i<d1.xforce.length;i++) { 
			d1.xforce[i] += d2.xforce[i];
			d1.yforce[i] += d2.yforce[i];
			d1.zforce[i] += d2.zforce[i];
		} 

		d1.epot         += d2.epot;
		d1.vir          += d2.vir;
		d1.interactions += d2.interactions;

		return d1;
	} 	
}

package section3.moldyn; 

class Particle {

	public double xcoord, ycoord, zcoord;
	public double xvelocity,yvelocity,zvelocity;
	public double xforce,yforce,zforce;

	public Particle(double xcoord, double ycoord, double zcoord, double xvelocity,
			double yvelocity,double zvelocity,double xforce, 
			double yforce, double zforce) {

		this.xcoord = xcoord; 
		this.ycoord = ycoord; 
		this.zcoord = zcoord;
		this.xvelocity = xvelocity;
		this.yvelocity = yvelocity;
		this.zvelocity = zvelocity;
		this.xforce = xforce;
		this.yforce = yforce;
		this.zforce = zforce;

	}

	public void domove(double side) {

		xcoord = xcoord + xvelocity + xforce;
		ycoord = ycoord + yvelocity + yforce;
		zcoord = zcoord + zvelocity + zforce;

		if(xcoord < 0) { xcoord = xcoord + side; } 
		if(xcoord > side) { xcoord = xcoord - side; }
		if(ycoord < 0) { ycoord = ycoord + side; }
		if(ycoord > side) { ycoord = ycoord - side; }
		if(zcoord < 0) { zcoord = zcoord + side; }
		if(zcoord > side) { zcoord = zcoord - side; }

		xvelocity = xvelocity + xforce;
		yvelocity = yvelocity + yforce;
		zvelocity = zvelocity + zforce;

		xforce = 0.0;
		yforce = 0.0;
		zforce = 0.0;

	}

	public void force(double side, double rcoff,int mdsize,int x) {

		double sideh;
		double rcoffs;

		double xx,yy,zz,xi,yi,zi,fxi,fyi,fzi;
		double rd,rrd,rrd2,rrd3,rrd4,rrd6,rrd7,r148;
		double forcex,forcey,forcez;

		int i;

		sideh = 0.5*side; 
		rcoffs = rcoff*rcoff;

		xi = xcoord;
		yi = ycoord;
		zi = zcoord;
		fxi = 0.0;
		fyi = 0.0;
		fzi = 0.0;

		for (i=x+1;i<mdsize;i++) {  
			xx = xi - MD.one[i].xcoord;
			yy = yi - MD.one[i].ycoord;
			zz = zi - MD.one[i].zcoord;

			if(xx < (-sideh)) { xx = xx + side; }
			if(xx > (sideh))  { xx = xx - side; }
			if(yy < (-sideh)) { yy = yy + side; }
			if(yy > (sideh))  { yy = yy - side; }
			if(zz < (-sideh)) { zz = zz + side; }
			if(zz > (sideh))  { zz = zz - side; }

			rd = xx*xx + yy*yy + zz*zz;

			if(rd <= rcoffs) {
				rrd = 1.0/rd;
				rrd2 = rrd*rrd;
				rrd3 = rrd2*rrd;
				rrd4 = rrd2*rrd2;
				rrd6 = rrd2*rrd4;
				rrd7 = rrd6*rrd;
				MD.epot = MD.epot + (rrd6 - rrd3);
				r148 = rrd7 - 0.5*rrd4;
				MD.vir = MD.vir - rd*r148;
				forcex = xx * r148;
				fxi = fxi + forcex;
				MD.one[i].xforce = MD.one[i].xforce - forcex;
				forcey = yy * r148;
				fyi = fyi + forcey;
				MD.one[i].yforce = MD.one[i].yforce - forcey;
				forcez = zz * r148;
				fzi = fzi + forcez;
				MD.one[i].zforce = MD.one[i].zforce - forcez; 
				MD.interactions++;
			}

		} 

		xforce = xforce + fxi;
		yforce = yforce + fyi;
		zforce = zforce + fzi;

	}

	public double mkekin(double hsq2) {

		double sumt = 0.0; 

		xforce = xforce * hsq2;
		yforce = yforce * hsq2;
		zforce = zforce * hsq2;
    
		xvelocity = xvelocity + xforce; 
		yvelocity = yvelocity + yforce; 
		zvelocity = zvelocity + zforce; 

		sumt = (xvelocity*xvelocity)+(yvelocity*yvelocity)+(zvelocity*zvelocity);
		return sumt;
	}

	public double velavg(double vaverh,double h) {
 
		double velt;
		double sq;

		sq = Math.sqrt(xvelocity*xvelocity + yvelocity*yvelocity +
			       zvelocity*zvelocity);

		if(sq > vaverh) { MD.count = MD.count + 1.0; }
    
		velt = sq;
		return velt;
	}

	public void dscal(double sc,int incx) {

		xvelocity = xvelocity * sc;
		yvelocity = yvelocity * sc;   
		zvelocity = zvelocity * sc;   



	}

}



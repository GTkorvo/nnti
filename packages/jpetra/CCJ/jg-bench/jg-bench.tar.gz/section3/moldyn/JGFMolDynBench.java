/**************************************************************************
*                                                                         *
*             Java Grande Forum Benchmark Suite - MPJ Version 1.0         *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         * 
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/


package section3.moldyn; 

import java.io.*;
import jgfutil.*; 
import CCJ.*;

public class JGFMolDynBench extends MD implements JGFSection3 {
	
	public JGFMolDynBench(int nprocess) throws Exception {
		super(nprocess);
	}
	
	public void JGFsetsize(int size){
		//this.size = size;
		// no-op
	}
	
	public void JGFinitialise(){
		initialise();
	}
	
	public void JGFapplication() throws Exception{ 
		
//		MPI.COMM_WORLD.Barrier();
		barrier(group);
		if(rank==0) {
			JGFInstrumentor.startTimer("Section3:MolDyn:Run");  
		}
		
		runiters();
		
//		MPI.COMM_WORLD.Barrier();
		barrier(group);
		if(rank==0) {
			JGFInstrumentor.stopTimer("Section3:MolDyn:Run");  
		}
	} 

	public void JGFvalidate(){
		
		if (rank == 0) { 
			double refval[] = {1731.4306625334357,7397.392307839352};
			double dev = Math.abs(ek - refval[size]);
			if (dev > 1.0e-12 ){			
				System.out.println("Validation failed");
				System.out.println("Kinetic Energy = " + ek + "  " + dev + "  " + size);
			}
		}
	}
	
	public void JGFtidyup(){    		
		one = null;
		System.gc();
	}

	public void JGFrun(int size) throws Exception{
		
		if(rank==0) {
			JGFInstrumentor.addTimer("Section3:MolDyn:Total", "Solutions",size);
			JGFInstrumentor.addTimer("Section3:MolDyn:Run", "Interactions",size);
		}
		
		JGFsetsize(size); 
		
		if(rank==0) {
			JGFInstrumentor.startTimer("Section3:MolDyn:Total");
		}
		
		JGFinitialise(); 
		JGFapplication(); 
		JGFvalidate(); 
		JGFtidyup(); 
		
		if(rank==0) {
			JGFInstrumentor.stopTimer("Section3:MolDyn:Total");
			
			JGFInstrumentor.addOpsToTimer("Section3:MolDyn:Run", (double) total_interactions);
			JGFInstrumentor.addOpsToTimer("Section3:MolDyn:Total", 1);
			
			JGFInstrumentor.printTimer("Section3:MolDyn:Run"); 
			JGFInstrumentor.printTimer("Section3:MolDyn:Total"); 
		}
		
	}	

	public void run() { 
		
		try { 
			JGFrun(size);
			System.exit(0);
		} catch (Exception e) { 
			System.err.println("Error in Run "+e);
			e.printStackTrace();
			System.exit(1);
		} 
	}

	public static void main(String[] args) throws Exception{
		
                /* Initialise CCJ */
		ColGroupMaster groupMaster = new ColGroupMaster(args);
		int nprocess = groupMaster.getNumberOfCpus();
		
		try {
			if (args.length < 1) { 
				size = 0;
			} else { 
				size = Integer.parseInt(args[0]);
				if (size < 0 || size > 1) { 
					throw new Exception("Invalid option " + size);
				}
			}

			JGFMolDynBench bc = new JGFMolDynBench(nprocess);
			groupMaster.addMember("myGroup", bc);
			ColGroup group = groupMaster.getGroup("myGroup", nprocess);
			bc.setGroup(group);

			if (group.getRank(bc) == 0) { 
				JGFInstrumentor.printHeader(3,size,nprocess);
			}

			bc.begin();
						
		} catch (Exception e) {
			System.err.println("Error in Main "+e);
			e.printStackTrace();
			System.exit(1);
		}		
	}
}
 

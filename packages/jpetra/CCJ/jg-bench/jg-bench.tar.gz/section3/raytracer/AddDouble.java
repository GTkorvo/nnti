package section3.raytracer; 

import java.io.Serializable;
import CCJ.*;

class AddDouble implements Reducible {

	public Serializable reduce(Serializable obj1, Serializable obj2) { 
		Double d1 = (Double) obj1;
		Double d2 = (Double) obj2;
		
		return new Double(d1.doubleValue() + d2.doubleValue());
	} 
}

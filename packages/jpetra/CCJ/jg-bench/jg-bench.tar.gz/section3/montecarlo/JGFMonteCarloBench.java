/**************************************************************************
*                                                                         *
*             Java Grande Forum Benchmark Suite - MPJ Version 1.0         *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         * 
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/


package  section3.montecarlo;

import java.io.*;
import jgfutil.*;
import CCJ.*;

public class JGFMonteCarloBench extends CallAppDemo implements JGFSection3 {

	public JGFMonteCarloBench(int nprocess) throws Exception {
		super(nprocess);
	}

	public void JGFsetsize(int size) {
		this.size = size;
		// no-op
	}

	public void JGFinitialise() {
		initialise();
	}

	public void JGFapplication() throws Exception {

		//MPI.COMM_WORLD.Barrier();
		barrier(group);

		if(rank==0) {
			JGFInstrumentor.startTimer("Section3:MonteCarlo:Run");
		}

		runiters();

		//MPI.COMM_WORLD.Barrier();
		barrier(group);

		if(rank==0) {
			JGFInstrumentor.stopTimer("Section3:MonteCarlo:Run");
		}

		if(rank==0) {
			presults();
		}

	}


	public void JGFvalidate() {
		double refval[] = {-0.0333976656762814,-0.03215796752868655};
		double dev = Math.abs(AppDemo.JGFavgExpectedReturnRateMC - refval[size]);

		if (dev > 1.0e-12 ) {
			System.out.println("Validation failed");
			System.out.println(" expectedReturnRate= " + AppDemo.JGFavgExpectedReturnRateMC + "  " + dev + "  " + size);
		}
	}

	public void JGFtidyup() {

		System.gc();
	}


	public void JGFrun(int size) throws Exception {

		if(rank==0) {
			JGFInstrumentor.addTimer("Section3:MonteCarlo:Total", "Solutions",size);
			JGFInstrumentor.addTimer("Section3:MonteCarlo:Run", "Samples",size);
		}

		JGFsetsize(size);

		//MPI.COMM_WORLD.Barrier();
		barrier(group);
		
		if(rank==0) {
			JGFInstrumentor.startTimer("Section3:MonteCarlo:Total");
		}

		JGFinitialise();
		JGFapplication();

		if(rank==0) {
			JGFvalidate();
		}

		JGFtidyup();

//		MPI.COMM_WORLD.Barrier();
		barrier(group);

		if(rank==0) {
			JGFInstrumentor.stopTimer("Section3:MonteCarlo:Total");

			JGFInstrumentor.addOpsToTimer("Section3:MonteCarlo:Run", (double) input[1] );
			JGFInstrumentor.addOpsToTimer("Section3:MonteCarlo:Total", 1);

			JGFInstrumentor.printTimer("Section3:MonteCarlo:Run");
			JGFInstrumentor.printTimer("Section3:MonteCarlo:Total");
		}
	}

	public void run() { 
		
		try { 
			JGFrun(size);
			System.exit(0);
		} catch (Exception e) { 
			System.err.println("Error in Run "+e);
			e.printStackTrace();
			System.exit(1);
		} 
	}

	public static void main(String[] args) throws Exception{
		
                /* Initialise CCJ */
		ColGroupMaster groupMaster = new ColGroupMaster(args);
		int nprocess = groupMaster.getNumberOfCpus();

		try {
			if (args.length < 1) { 
				size = 0;
			} else { 
				size = Integer.parseInt(args[0]);
				if (size < 0 || size > 2) { 
					throw new Exception("Invalid option " + size);
				}
			}

			JGFMonteCarloBench bc = new JGFMonteCarloBench(nprocess);
			groupMaster.addMember("myGroup", bc);
			ColGroup group = groupMaster.getGroup("myGroup", nprocess);
			bc.setGroup(group);

			if (group.getRank(bc) == 0) { 
				JGFInstrumentor.printHeader(3,size,nprocess);
			}

			bc.begin();
						
		} catch (Exception e) {
			System.err.println("Error in Main "+e);
			e.printStackTrace();
			System.exit(1);
		}		
	}
}


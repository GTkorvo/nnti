import CCJ.*;
import java.io.Serializable;

class DoubleObjectArray implements Partitionable {

	public obj_double [] array;
	public int n;
	
	public DoubleObjectArray(int length) {
		array = new obj_double[length];
		n = length;
	}
	
	public int size() {
		return array.length;
	}	
	
	public void setElementAt(int index, int groupSize, Serializable object) {
		
		obj_double [] other = ( obj_double [] ) object;
		
		int d = n / groupSize;
		int m = n % groupSize;
		
		int offset = index * d;
		int size = d;
		
		if (index >= (groupSize - m)) {
			size += 1;
			offset += index - (groupSize - m);
		}
		
		System.arraycopy(other, 0, array, offset, size);
	}
	
	public Serializable elementAt(int index, int groupSize) {
		int size = array.length / groupSize;
		if ((array.length % groupSize) != 0) {
			throw new RuntimeException("Unbalanced distribution not supported.");
		}
 	        obj_double [] other = new obj_double[size];
		int myIndex = index * size;
		
		System.arraycopy(array, myIndex, other, 0, size);
		return other;
	}
			
	public String toString() {
		return "DoubleArray([" + array.length + "])";
	}
}

import java.io.*;
import jgfutil.*; 

class obj_double implements Serializable {

  double x;

  public obj_double(double x) {
   this.x = x;
  }

}


/**************************************************************************
*                                                                         *
*         Java Grande Forum Benchmark Suite - MPJ Version 1.0             *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         * 
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/


import java.io.*;
import jgfutil.*; 
import CCJ.*;

public class JGFReduceBench extends ColMember implements JGFSection1{

	public int nprocess;
	public int rank;
	
	private static final int INITSIZE = 1;
	private static final int MAXSIZE =  1000000;
	private static final double TARGETTIME = 10.0;
	private static final int MLOOPSIZE = 2;
	private static final int SMAX = 5000000;
	private static final int SMIN = 4;
	
	private ColGroup group;

	private AddDoubleArray sum;

	void setGroup(ColGroup group) throws Exception {
		this.group = group;
		rank = group.getRank(this);
	}

	public JGFReduceBench(int nprocess) throws Exception {
		this.nprocess=nprocess;
		sum = new AddDoubleArray();
	}
	
	public void JGFrun() throws Exception {
		
		int size,i,l,m_size;
		double logsize;
		double b_time; 
		b_time = 0.0;
		Double time;
		
		m_size = 0;
		logsize = Math.log((double) SMAX) - Math.log((double) SMIN);
		
		/* Reduce an array of doubles */
		
		/* Create the timers */ 
		if(rank==0){
			JGFInstrumentor.addTimer("Section1:Reduce:Double", "bytes");
			JGFInstrumentor.addTimer("Section1:Reduce:Barrier", "barriers");
		}

		/* loop over no of different message sizes */
		for(l=0;l<MLOOPSIZE;l++){
			
			/* Initialize the sending data */
			m_size = (int)(Math.exp(Math.log((double)SMIN)+(double) ((double) l/(double) MLOOPSIZE*logsize)));

			// don't need receive buffers in CCJ
			double [] send_arr = new double[m_size];
			double [] recv_arr = null;

			time = new Double(0.0);
			size=INITSIZE;
			
			//MPI.COMM_WORLD.Barrier();
			barrier(group);

			/* Start the timer */
			while (time.doubleValue() < TARGETTIME && size < MAXSIZE){
				if(rank==0){
					JGFInstrumentor.resetTimer("Section1:Reduce:Double");
					JGFInstrumentor.startTimer("Section1:Reduce:Double");
				}

				/* Carryout the broadcast operation */
				for (int k=0; k<size; k++){
					//MPI.COMM_WORLD.Reduce(send_arr,0,recv_arr,0,send_arr.length,MPI.DOUBLE,MPI.SUM,0);
					//MPI.COMM_WORLD.Barrier();
					recv_arr = (double []) reduce(group, send_arr, sum, 0);
					barrier(group);					
				}

				/* Stop the timer */
				if(rank==0){
					JGFInstrumentor.stopTimer("Section1:Reduce:Double"); 
					time = new Double(JGFInstrumentor.readTimer("Section1:Reduce:Double")); 
					JGFInstrumentor.addOpsToTimer("Section1:Reduce:Double",(double) size*send_arr.length*8); 
				}

				/* Broadcast time to the other processes */
				//MPI.COMM_WORLD.Barrier();
				//MPI.COMM_WORLD.Bcast(time,0,1,MPI.DOUBLE,0);
				barrier(group);
				time = (Double) broadcast(group, time, 0);
				size *=2;
			}
 
			size /=2;

			/* determine the cost of the Barrier, subtract the cost and write out the performance time */
			//MPI.COMM_WORLD.Barrier();
			barrier(group);

			if(rank==0) {
				JGFInstrumentor.resetTimer("Section1:Reduce:Barrier");
				JGFInstrumentor.startTimer("Section1:Reduce:Barrier");
			}
			
			for (int k=0; k<size; k++){
				//MPI.COMM_WORLD.Barrier();
				barrier(group);
			}

			if(rank==0) {
				JGFInstrumentor.stopTimer("Section1:Reduce:Barrier");
				b_time = JGFInstrumentor.readTimer("Section1:Reduce:Barrier");
				JGFInstrumentor.addTimeToTimer("Section1:Reduce:Double", -b_time);
				JGFInstrumentor.printperfTimer("Section1:Reduce:Double", send_arr.length); 
			}			
		}		

		// Where is the object [] case ??
	}
	
		
	public void run() { 
		
		try { 
			JGFrun();
			System.exit(0);
		} catch (Exception e) { 
			System.err.println("Error in Run "+e);
			e.printStackTrace();
			System.exit(1);
		} 
	}

	public static void main(String[] args) throws Exception{
		
		/* Initialise CCJ */
		ColGroupMaster groupMaster = new ColGroupMaster(args);
		int nprocess = groupMaster.getNumberOfCpus();
		
		try {
			JGFReduceBench bc = new JGFReduceBench(nprocess);
			groupMaster.addMember("myGroup", bc);
			ColGroup group = groupMaster.getGroup("myGroup", nprocess);
			bc.setGroup(group);
			
			if (group.getRank(bc) == 0) { 
				JGFInstrumentor.printHeader(1,0,nprocess);
			}
			bc.begin();
			
		} catch (Exception e) {
			System.err.println("Error in Main "+e);
			e.printStackTrace();
			System.exit(1);
		}		
	}
}


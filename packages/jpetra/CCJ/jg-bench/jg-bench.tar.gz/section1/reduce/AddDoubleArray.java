import CCJ.*;
import java.io.Serializable;

class AddDoubleArray implements Reducible {

	public Serializable reduce(Serializable obj1, Serializable obj2) { 		
		double [] a1 = (double []) obj1;
		double [] a2 = (double []) obj2;		

		for (int i=0;i<a1.length;i++) { 
			a1[i] += a2[i];
		} 

		return a1;
	} 
}

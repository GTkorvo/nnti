/**************************************************************************
*                                                                         *
*         Java Grande Forum Benchmark Suite - MPJ Version 1.0             *
*                                                                         *
*                            produced by                                  *
*                                                                         *
*                  Java Grande Benchmarking Project                       *
*                                                                         *
*                                at                                       *
*                                                                         *
*                Edinburgh Parallel Computing Centre                      *
*                                                                         * 
*                email: epcc-javagrande@epcc.ed.ac.uk                     *
*                                                                         *
*                                                                         *
*      This version copyright (c) The University of Edinburgh, 2001.      *
*                         All rights reserved.                            *
*                                                                         *
**************************************************************************/


import java.io.*;
import jgfutil.*; 
import CCJ.*;

public class JGFScatterBench extends ColMember implements JGFSection1 { 

	public int nprocess;
	public int rank;
	
	private static final int INITSIZE = 1;
	private static final int MAXSIZE =  1000000;
	private static final double TARGETTIME = 10.0;
	private static final int MLOOPSIZE = 2;
	private static final int SMAX = 5000000;
	private static final int SMIN = 4;

	private ColGroup group;

	void setGroup(ColGroup group) throws Exception {
		this.group = group;
		rank = group.getRank(this);
	}

	public JGFScatterBench(int nprocess) throws Exception {
		this.nprocess=nprocess;
	}

	public void JGFrun() throws Exception {

		int size,i,l,m_size;
		double logsize;
		double b_time; 
		b_time = 0.0;
		Double time;
			
		m_size = 0;
		logsize = Math.log((double) SMAX) - Math.log((double) SMIN);
			
		/* Scatter an array of doubles */

		/* Create the timers */ 
		if(rank==0){
			JGFInstrumentor.addTimer("Section1:Scatter:Double", "bytes");
			JGFInstrumentor.addTimer("Section1:Scatter:Barrier", "barriers");
		}
						
		/* loop over no of different message sizes */
		for(l=0;l<MLOOPSIZE;l++){

				/* Initialize the sending data */
			m_size = (int)(Math.exp(Math.log((double)SMIN)+(double) ((double) l/(double) MLOOPSIZE*logsize)));

			DoubleArray send_arr = null;
			double [] recv_arr = null; 

			if (rank == 0) { 
				send_arr = new DoubleArray(m_size*nprocess);
			}

			time = new Double(0.0);
			size = INITSIZE;
				
			//MPI.COMM_WORLD.Barrier();
			barrier(group);

                        /* Start the timer */
			while (time.doubleValue() < TARGETTIME && size < MAXSIZE){
				if(rank==0){
					JGFInstrumentor.resetTimer("Section1:Scatter:Double");
					JGFInstrumentor.startTimer("Section1:Scatter:Double");
				}

				/* Carryout the broadcast operation */
				for (int k=0; k<size; k++){
					//MPI.COMM_WORLD.Scatter(send_arr,0,recv_arr.length,MPI.DOUBLE,recv_arr,0,recv_arr.length,MPI.DOUBLE,0);
					//MPI.COMM_WORLD.Barrier();
					recv_arr = (double []) scatter(group, send_arr, 0);
					barrier(group);
				}

				/* Stop the timer. Note that this reports no of bytes sent per process  */
				if(rank==0){
					JGFInstrumentor.stopTimer("Section1:Scatter:Double"); 
					time = new Double(JGFInstrumentor.readTimer("Section1:Scatter:Double")); 
					JGFInstrumentor.addOpsToTimer("Section1:Scatter:Double",(double) size*recv_arr.length*8); 
				}

				/* Broadcast time to the other processes */
				//MPI.COMM_WORLD.Barrier();
				//MPI.COMM_WORLD.Bcast(time,0,1,MPI.DOUBLE,0);
				barrier(group);
				time = (Double) broadcast(group, time, 0);
				size *=2;
			}
 
			size /=2;

				/* determine the cost of the Barrier, subtract the cost and write out the performance time */
				//MPI.COMM_WORLD.Barrier();
			barrier(group);

			if(rank==0) {
				JGFInstrumentor.resetTimer("Section1:Scatter:Barrier");
				JGFInstrumentor.startTimer("Section1:Scatter:Barrier");
			}
				
			for (int k=0; k<size; k++){
				//MPI.COMM_WORLD.Barrier();
				barrier(group);
			}
				
			if(rank==0) {
				JGFInstrumentor.stopTimer("Section1:Scatter:Barrier");
				b_time = JGFInstrumentor.readTimer("Section1:Scatter:Barrier");
				JGFInstrumentor.addTimeToTimer("Section1:Scatter:Double", -b_time);
				JGFInstrumentor.printperfTimer("Section1:Scatter:Double",recv_arr.length); 
			}
				
		}
			
		/* Scatter an array of objects containing a double */

		/* Create the timer */
		if(rank==0){
			JGFInstrumentor.addTimer("Section1:Scatter:Object", "objects");
		}
						
		/* loop over no of different message sizes */
		for(l=0;l<MLOOPSIZE;l++){

				/* Initialize the sending data */
			m_size = (int)(Math.exp(Math.log((double)SMIN)+(double) ((double) l/(double) MLOOPSIZE*logsize)));
			//obj_double [] recv_arr_obj = new obj_double[m_size];
			//obj_double [] send_arr_obj = new obj_double[m_size*nprocess];

			DoubleObjectArray send_arr_obj = null;
			obj_double [] recv_arr_obj = null; 

			if (rank == 0) { 
				send_arr_obj = new DoubleObjectArray(m_size*nprocess);
				for(int k=0;k<m_size*nprocess;k++){
					send_arr_obj.array[k] = new obj_double(0.0);
				}				
			}

			time = new Double(0.0);
			size=INITSIZE;
				
				//MPI.COMM_WORLD.Barrier();
			barrier(group);

				/* Start the timer */
			while (time.doubleValue() < TARGETTIME && size < MAXSIZE){
				if(rank==0){
					JGFInstrumentor.resetTimer("Section1:Scatter:Object");
					JGFInstrumentor.startTimer("Section1:Scatter:Object");
				}

				/* Carryout the broadcast operation */
				for (int k=0; k<size; k++){
					//MPI.COMM_WORLD.Scatter(send_arr_obj,0,recv_arr_obj.length,MPI.OBJECT,recv_arr_obj,0,recv_arr_obj.length,MPI.OBJECT,0);
					//MPI.COMM_WORLD.Barrier();						
					recv_arr_obj = (obj_double []) scatter(group, send_arr_obj, 0);
					barrier(group);
				}

				/* Stop the timer */
				if(rank==0){
					JGFInstrumentor.stopTimer("Section1:Scatter:Object");
					time = new Double(JGFInstrumentor.readTimer("Section1:Scatter:Object"));
					JGFInstrumentor.addOpsToTimer("Section1:Scatter:Object",(double) size*recv_arr_obj.length);
				}

				/* Broadcast time to the other processes */
				//MPI.COMM_WORLD.Barrier();
				//MPI.COMM_WORLD.Bcast(time,0,1,MPI.DOUBLE,0);
				barrier(group);
				time = (Double) broadcast(group, time, 0);
				size *=2;
			}
			size /=2;

			/* determine the cost of the Barrier, subtract the cost and write out the performance time */
			//MPI.COMM_WORLD.Barrier();
			barrier(group);
			if(rank==0) {
				JGFInstrumentor.resetTimer("Section1:Scatter:Barrier");
				JGFInstrumentor.startTimer("Section1:Scatter:Barrier");
			}
				
			for (int k=0; k<size; k++){
				//MPI.COMM_WORLD.Barrier();
				barrier(group);
			}
				
			if(rank==0) {
				JGFInstrumentor.stopTimer("Section1:Scatter:Barrier");
				b_time = JGFInstrumentor.readTimer("Section1:Scatter:Barrier");
				JGFInstrumentor.addTimeToTimer("Section1:Scatter:Object", -b_time);
				JGFInstrumentor.printperfTimer("Section1:Scatter:Object",recv_arr_obj.length);
			}
				
		}						
	}

	public void run() { 
		
		try { 
			JGFrun();
			System.exit(0);
		} catch (Exception e) { 
			System.err.println("Error in Run "+e);
			e.printStackTrace();
			System.exit(1);
		} 
	}

	public static void main(String[] args) throws Exception{
		
		/* Initialise CCJ */
		ColGroupMaster groupMaster = new ColGroupMaster(args);
		int nprocess = groupMaster.getNumberOfCpus();
		
		try {
			JGFScatterBench bc = new JGFScatterBench(nprocess);
			groupMaster.addMember("myGroup", bc);
			ColGroup group = groupMaster.getGroup("myGroup", nprocess);
			bc.setGroup(group);
			
			if (group.getRank(bc) == 0) { 
				JGFInstrumentor.printHeader(1,0,nprocess);
			}
			bc.begin();
			
		} catch (Exception e) {
			System.err.println("Error in Main "+e);
			e.printStackTrace();
			System.exit(1);
		}		
	}
}

